# Site Analysis: Let's Shop (Rahul Shetty Academy client)

Base URL: `https://rahulshettyacademy.com/client/`

## How this analysis was done, and its limits

The application is an **Angular single-page app with hash routing**. A plain HTTP fetch of the login URL
returns only the empty shell (title "Let's Shop", `noindex`), because every screen is rendered client-side. The
locators below therefore come from the app's standard Angular DOM conventions (element ids, `formcontrolname`,
`routerlink` attributes, Bootstrap/ngx-toastr classes), **not** from a live, rendered inspection of the page.

**Please verify before the first run:** open each page in Chrome DevTools and confirm the locator column below.
Locators marked ⚠ are the ones I am least sure about and the first place to look if a step fails.

Implications of the SPA design that shaped the framework:

* No full page loads between screens, so waits target **elements and Angular animation state**, not `document.readyState`
  alone (`WaitUtils.angularIdle()` waits for `.ng-animating` to disappear).
* Hash routes (`#/dashboard/cart`), so URL checks use `urlContains(...)`.
* Notifications are **toasts** that overlay the page and auto-dismiss.
* The cart and order history live **server-side per account**, which drives the "empty the cart first" step.

## Screens, routes and flows

| Screen | Route | Page class |
|---|---|---|
| Login | `#/auth/login` | `LoginPage` |
| Register | `#/auth/register` | `RegisterPage` |
| Dashboard (catalogue) | `#/dashboard/dash` | `DashboardPage` |
| Cart | `#/dashboard/cart` | `CartPage` |
| Checkout / payment | `#/dashboard/order?...` | `CheckoutPage` |
| Order confirmation | `#/dashboard/thanks` | `OrderConfirmationPage` |
| Order history | `#/dashboard/myorders` | `OrdersPage` |
| Top nav (all authenticated screens) | n/a | `HeaderComponent` |
| Toast notifications | n/a | `ToastComponent` |

```
Register ──► Login ──► Dashboard ──► Cart ──► Checkout ──► Order confirmation
                          │                                        │
                          └──────────────► Orders (history) ◄──────┘
```

## Locator catalogue

### Login: `LoginPage`
| Element | Locator |
|---|---|
| Email | `id=userEmail` |
| Password | `id=userPassword` |
| Login button | `id=login` |
| Register link | `a[routerlink*='register']` ⚠ |
| Field validation text ("*Email is required", "*Enter Valid Email") | `.invalid-feedback` ⚠ |
| Error toast ("Incorrect email or password.") | `#toast-container [role='alertdialog'], #toast-container .toast-message` |

Behaviour: validation messages appear once a field is *touched*, so `login()` presses TAB after each field.

### Register: `RegisterPage`
| Element | Locator |
|---|---|
| First / last name | `id=firstName`, `id=lastName` |
| Email, phone | `id=userEmail`, `id=userMobile` |
| Occupation (select) | `select[formcontrolname='occupation']` ⚠ |
| Gender radios | `input[value='Male']`, `input[value='Female']` ⚠ |
| Password, confirm | `id=userPassword`, `id=confirmPassword` |
| "I am 18 or older" checkbox | `input[type='checkbox']` ⚠ |
| Register button | `id=login` |
| Success heading | `.headcolor` ⚠ ("Account Created Successfully") |
| Login button after success | `//button[normalize-space()='Login']` ⚠ |

### Top navigation: `HeaderComponent`
| Element | Locator |
|---|---|
| HOME | `button[routerlink*='dash']` |
| ORDERS | `button[routerlink*='myorders']` |
| Cart | `button[routerlink*='cart']` |
| Cart count badge | `button[routerlink*='cart'] label` ⚠ |
| Sign Out | `//button[contains(normalize-space(.),'Sign Out')]` |

### Dashboard: `DashboardPage`
| Element | Locator |
|---|---|
| Product card | `.card-body` |
| Product title (inside card) | `b` |
| Add To Cart (inside card) | `button:last-of-type` |
| Busy overlay | `.ng-animating` |

### Cart: `CartPage`
| Element | Locator |
|---|---|
| Name and price headings | `.cartSection h3` (price rows start with "MRP", filtered out) |
| Remove button | `.cartSection button.btn-danger` |
| Checkout | `.totalRow button` |
| Empty message | `//h1[contains(.,'No Products')]` |

### Checkout: `CheckoutPage`
| Element | Locator |
|---|---|
| Country input | `input[placeholder='Select Country']` |
| Country suggestions | `.ta-results button` |
| Place Order | `.action__submit` |

### Confirmation and history: `OrderConfirmationPage`, `OrdersPage`
| Element | Locator |
|---|---|
| Thank-you heading | `.hero-primary` (rendered upper-case by CSS, compare ignoring case) |
| Order ids on confirmation | `.em-spacer-1 .ng-star-inserted` (text like `| 65ab… |`) |
| History rows | `tbody tr`; id in `th`, product name in `td:nth-child(3)` ⚠ |
| Empty history message | `//*[contains(text(),'No Orders')]` |

## Test-design decisions that follow from the analysis

1. **Cart reset**: `Given my cart is empty` runs in Backgrounds, because the cart persists per account.
2. **Toast-based synchronisation** after Add To Cart (`Product Added To Cart`), then wait for `.ng-animating` to clear.
3. **Self-sufficient scenario**: one E2E registers a random user first, so it does not depend on the shared demo account.
4. **Product names** (`ZARA COAT 3`, `ADIDAS ORIGINAL`) are catalogue data. If the catalogue changes, update
   `orders.json` and the feature files.
5. **Order verification** compares the ids shown on the confirmation page with the history table, rather than
   assuming one id per product.
