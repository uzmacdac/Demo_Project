# RSA Client: Selenium + TestNG + Cucumber (Java) Framework

BDD end-to-end framework for **Let's Shop**, the Rahul Shetty Academy practice app
(`https://rahulshettyacademy.com/client/#/auth/login`).

| Concern | Choice |
|---|---|
| Language / build | Java 17, Maven |
| Browser automation | Selenium 4.25 (Selenium Manager resolves drivers, no WebDriverManager needed) |
| Test engine | TestNG 7.10 driving Cucumber 7.20 (`AbstractTestNGCucumberTests`) |
| Design pattern | Page Object Model + **PageFactory** (`@FindBy`, `PageFactory.initElements(driver, this)`) |
| Dependency injection | Cucumber PicoContainer (`TestContext` per scenario) |
| Reports | Extent Spark + Allure + Cucumber HTML/JSON |
| Logging | Log4j2 (console + rolling file) |
| Test data | JSON, Excel (Apache POI), random generators |

## Quick start

```bash
# prerequisites: JDK 17+, Maven 3.9+, Chrome (or Firefox / Edge)
mvn clean test                                          # everything, Chrome, headed
mvn clean test -Dheadless=true                          # CI style
mvn clean test -Dcucumber.filter.tags="@smoke"          # tag filter
mvn clean test -Dcucumber.filter.tags="@e2e and not @registration"
mvn clean test -Dbrowser=firefox -Denv=stage
mvn clean test -Dthread.count=3                         # parallel scenarios (see note below)
mvn test -Dtest=FailedScenariosRunner                   # re-run only last run's failures
```

Tags available: `@smoke @regression @login @registration @cart @e2e @positive @negative @data-driven @ignore`.

### Reports (all under `target/`)

| Report | Where | How to open |
|---|---|---|
| Extent Spark | `target/extent-reports/ExtentSpark.html` | open in a browser |
| Allure | `target/allure-results` | `mvn allure:serve` (or `allure serve target/allure-results`) |
| Cucumber HTML | `target/cucumber-reports/cucumber.html` | open in a browser |
| Logs | `logs/automation.log` | text |
| Failure screenshots | `target/screenshots/` (also embedded in Extent and Allure) | |

## Project layout

```
rsa-selenium-bdd-framework
├── pom.xml
├── README.md
├── docs/
│   ├── ARCHITECTURE.md        <- layers, control flow, hooks, execution flow
│   └── SITE_ANALYSIS.md       <- pages, routes, locators, flows of the app
├── src/main/java/com/rsa            (framework code: reusable, no Cucumber glue)
│   ├── config/        Environment, EnvironmentManager, ConfigManager
│   ├── base/          DriverFactory, BaseComponent, BasePage
│   ├── actions/       WebActions
│   ├── assertions/    Assertions, SoftAssertions
│   ├── components/    HeaderComponent, ToastComponent
│   ├── pages/         LoginPage, RegisterPage, DashboardPage, CartPage,
│   │                  CheckoutPage, OrderConfirmationPage, OrdersPage
│   ├── context/       TestContext, ScenarioContext, ContextKey, PageObjectManager
│   ├── models/        UserData, OrderData
│   ├── utils/         ExcelUtils, JsonUtils, ScreenshotUtils, WaitUtils,
│   │                  DataReader, RandomDataUtils, ResourceUtils, ReportUtils
│   ├── retry/         RetryAnalyzer, RetryTransformer
│   ├── listeners/     TestListener, ThreadCountAlterListener
│   └── constants/     FrameworkConstants
├── src/test/java/com/rsa            (Cucumber / TestNG layer)
│   ├── hooks/         Hooks
│   ├── runners/       TestRunner, FailedScenariosRunner
│   └── stepdefinitions/ LoginSteps, RegistrationSteps, DashboardSteps,
│                        CartSteps, CheckoutSteps, OrdersSteps
└── src/test/resources
    ├── features/      login, registration, cart, e2e_order (.feature)
    ├── config/        common.properties, qa.properties, stage.properties
    ├── testdata/      users.json, orders.json, LoginData.xlsx
    ├── testng.xml, log4j2.xml, extent.properties, spark-config.xml,
    └── allure.properties, cucumber.properties
```

## Configuration

Precedence, highest first: `-Dkey=value` → `config/<env>.properties` → `config/common.properties`.
`-Denv=qa|stage|prod` picks the environment file (default `qa`). Useful keys:

| Key | Default | Meaning |
|---|---|---|
| `base.url` | per environment | Application root, hash routes are appended |
| `browser` | `chrome` | `chrome`, `firefox`, `edge` |
| `headless` | `false` | |
| `execution.mode` / `grid.url` | `local` / `http://localhost:4444` | `remote` uses a Selenium Grid |
| `explicit.wait.seconds` | `15` | Every wait in the framework |
| `retry.count` | `1` | Re-runs of a failed scenario |
| `thread.count` | `1` | Parallel scenarios |
| `screenshot.on.failure` / `screenshot.every.step` | `true` / `false` | |
| `default.user` | `standard_user` | Key in `users.json` |

## Notes before you run it

1. **Credentials.** `users.json` uses the long-standing public demo account of this practice site. Anyone can
   change that account, so if login scenarios fail, replace the values (or rely on the `@registration`
   scenarios, which create their own user).
2. **Parallel runs share the account's cart.** The cart is stored server-side per user, so with
   `-Dthread.count` above 1, give each thread its own user, otherwise scenarios clear each other's cart.
3. **Orders accumulate.** Each E2E run adds orders to the account's history. The site offers no cleanup API,
   so the framework only asserts that new order ids appear.
4. **Locators.** See `docs/SITE_ANALYSIS.md` for how they were derived and which ones to re-check first
   if the site changes.

## Extending

* New page: extend `BasePage`, declare `@FindBy` fields, add a getter in `PageObjectManager`.
* New step: add to a `*Steps` class that takes `TestContext` in its constructor.
* New environment: add `config/<name>.properties` and a constant in `Environment`.
* Full explanation: `docs/ARCHITECTURE.md`.
