@e2e @regression
Feature: End-to-end order placement
  As a shopper
  I want to buy products and see them in my order history
  So that I know my purchase was recorded

  @smoke
  Scenario: Place an order for a single product and verify it in order history
    Given I am logged in as "standard_user"
    And my cart is empty
    When I add product "ZARA COAT 3" to the cart
    And I open the cart
    Then the cart should contain product "ZARA COAT 3"
    When I proceed to checkout
    And I select country "India" by typing "ind"
    And I place the order
    Then I should see the order confirmation message "Thankyou for the order."
    And an order id should be generated
    When I open the orders page
    Then all generated orders should be listed in my order history

  @data-driven
  Scenario Outline: Place an order using test data "<orderKey>"
    Given I am logged in as "standard_user"
    And my cart is empty
    When I add the products from order data "<orderKey>"
    And I open the cart
    Then the cart should contain the products I added
    When I proceed to checkout
    And I complete checkout with order data "<orderKey>"
    Then I should see the order confirmation message "Thankyou for the order."
    And an order id should be generated
    When I open the orders page
    Then all generated orders should be listed in my order history

    Examples:
      | orderKey          |
      | single_item_order |
      | multi_item_order  |

  @registration
  Scenario: A brand-new user registers and completes a first purchase
    Given I am on the registration page
    When I register a new user with random data
    Then I should see the account created confirmation
    Given I login with the newly registered user
    When I add product "ADIDAS ORIGINAL" to the cart
    And I open the cart
    Then the cart should contain product "ADIDAS ORIGINAL"
    When I proceed to checkout
    And I select country "India" by typing "ind"
    And I place the order
    Then I should see the order confirmation message "Thankyou for the order."
    And an order id should be generated
    When I open the orders page
    Then all generated orders should be listed in my order history
