@login @regression
Feature: Login
  As a shopper
  I want to sign in to the Let's Shop client
  So that I can browse products and place orders

  Background:
    Given I am on the login page

  @smoke @positive
  Scenario: Login with valid credentials
    When I login as "standard_user"
    Then I should land on the dashboard
    And the dashboard should display products

  @negative @data-driven
  Scenario Outline: Login is rejected for invalid data from Excel (<testCaseId>)
    When I login using Excel test data "<testCaseId>"
    Then I should see the expected login error

    Examples:
      | testCaseId          |
      | invalid_password    |
      | unregistered_email  |
      | empty_email         |
      | empty_password      |
      | invalid_email_format |
