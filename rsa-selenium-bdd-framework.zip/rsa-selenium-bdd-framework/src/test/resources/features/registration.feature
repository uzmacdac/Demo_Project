@registration @regression
Feature: Registration
  As a new shopper
  I want to create an account
  So that I can sign in and shop

  @positive
  Scenario: Register a new user and sign in with it
    Given I am on the registration page
    When I register a new user with random data
    Then I should see the account created confirmation
    When I login with the newly registered user
    Then I should land on the dashboard
