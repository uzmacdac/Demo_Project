@cart @regression
Feature: Shopping cart
  As a logged-in shopper
  I want to manage items in my cart
  So that I only buy what I intend to

  Background:
    Given I am logged in as "standard_user"
    And my cart is empty

  @smoke
  Scenario: Add a single product to the cart
    When I add product "ZARA COAT 3" to the cart
    And I open the cart
    Then the cart should contain product "ZARA COAT 3"

  Scenario: Add multiple products to the cart
    When I add the following products to the cart:
      | ZARA COAT 3     |
      | ADIDAS ORIGINAL |
    Then the cart badge should show 2 items
    When I open the cart
    Then the cart should contain the products I added

  Scenario: Remove a product from the cart
    When I add product "ZARA COAT 3" to the cart
    And I open the cart
    And I remove product "ZARA COAT 3" from the cart
    Then the cart should not contain product "ZARA COAT 3"
    And the cart should be empty
