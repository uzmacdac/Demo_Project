package com.rsa.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

/**
 * Re-executes only the scenarios that failed in the previous run (listed in target/rerun.txt by
 * the "rerun" plugin of TestRunner).
 *
 * Usage:  mvn test -Dtest=FailedScenariosRunner
 * (-Dtest bypasses testng.xml, so run-time listeners such as the retry transformer are not applied.)
 */
@CucumberOptions(
        features = "@target/rerun.txt",
        glue = {"com.rsa.stepdefinitions", "com.rsa.hooks"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/rerun.html",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
        },
        monochrome = true
)
public class FailedScenariosRunner extends AbstractTestNGCucumberTests {
}
