package com.rsa.runners;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

/**
 * The single entry point TestNG / Surefire executes.
 *
 * Filter scenarios with tags from the command line: -Dcucumber.filter.tags="@smoke and not @registration"
 * Parallelism is controlled by -Dthread.count=N (see ThreadCountAlterListener).
 */
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.rsa.stepdefinitions", "com.rsa.hooks"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "rerun:target/rerun.txt",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        monochrome = true
)
public class TestRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
