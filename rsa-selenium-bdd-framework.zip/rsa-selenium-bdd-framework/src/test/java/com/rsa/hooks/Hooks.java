package com.rsa.hooks;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.rsa.base.DriverFactory;
import com.rsa.config.ConfigManager;
import com.rsa.config.EnvironmentManager;
import com.rsa.constants.FrameworkConstants;
import com.rsa.context.TestContext;
import com.rsa.utils.ReportUtils;
import com.rsa.utils.ScreenshotUtils;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;

/**
 * Cucumber lifecycle hooks.
 *
 * Order for one scenario:  @Before (browser starts)  ->  steps (each followed by @AfterStep)  ->  @After (browser quits).
 * @BeforeAll / @AfterAll run once per test run, outside any scenario.
 */
public class Hooks {

    private static final Logger LOG = LogManager.getLogger(Hooks.class);

    private final TestContext context;

    public Hooks(TestContext context) {
        this.context = context;
    }

    @BeforeAll
    public static void beforeAll() throws Exception {
        Files.createDirectories(Paths.get(FrameworkConstants.SCREENSHOT_DIR));
        ReportUtils.writeAllureEnvironment();
        LOG.info("==== RUN START | env={} | browser={} | headless={} ====", EnvironmentManager.current(),
                ConfigManager.get().getBrowser(), ConfigManager.get().isHeadless());
    }

    @Before(order = 0)
    public void beforeScenario(Scenario scenario) {
        LOG.info("---- SCENARIO START: '{}' {} ----", scenario.getName(), scenario.getSourceTagNames());
        DriverFactory.initDriver();
    }

    @AfterStep
    public void afterStep(Scenario scenario) {
        if (!DriverFactory.hasDriver()) {
            return;
        }
        ConfigManager config = ConfigManager.get();
        boolean failedStep = scenario.isFailed() && config.getBoolean("screenshot.on.failure", true);
        boolean everyStep = config.getBoolean("screenshot.every.step", false);
        if (failedStep || everyStep) {
            byte[] png = ScreenshotUtils.asBytes(context.driver());
            scenario.attach(png, "image/png", failedStep ? "Failure screenshot" : "Step screenshot");
            if (failedStep) {
                ScreenshotUtils.saveToFile(context.driver(), scenario.getName());
                scenario.log("Failed at URL: " + context.driver().getCurrentUrl());
            }
        }
    }

    @After(order = 0)
    public void afterScenario(Scenario scenario) {
        LOG.info("---- SCENARIO END  : '{}' -> {} ----", scenario.getName(), scenario.getStatus());
        DriverFactory.quitDriver();
    }

    @AfterAll
    public static void afterAll() {
        LOG.info("==== RUN END ====");
    }
}
