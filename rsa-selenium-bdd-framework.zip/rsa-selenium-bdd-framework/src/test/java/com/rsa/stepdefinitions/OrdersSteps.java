package com.rsa.stepdefinitions;

import java.util.List;

import com.rsa.assertions.SoftAssertions;
import com.rsa.context.ContextKey;
import com.rsa.context.TestContext;
import com.rsa.pages.OrdersPage;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OrdersSteps {

    private final TestContext context;

    public OrdersSteps(TestContext context) {
        this.context = context;
    }

    @When("I open the orders page")
    public void iOpenTheOrdersPage() {
        context.pages().header().goToOrders();
    }

    /** Soft assertions: if two of three ids are missing, the failure lists both. */
    @Then("all generated orders should be listed in my order history")
    public void allGeneratedOrdersShouldBeListedInMyOrderHistory() {
        List<String> orderIds = context.scenario().getList(ContextKey.ORDER_IDS);
        OrdersPage ordersPage = context.pages().ordersPage();
        SoftAssertions soft = new SoftAssertions();
        for (String id : orderIds) {
            soft.isTrue(ordersPage.isOrderPresent(id), "Order " + id + " is listed in order history");
        }
        soft.assertAll();
    }

    @Then("the order history should list product {string}")
    public void theOrderHistoryShouldListProduct(String productName) {
        SoftAssertions soft = new SoftAssertions();
        soft.isTrue(context.pages().ordersPage().isProductPresent(productName),
                "Order history lists '" + productName + "'");
        soft.assertAll();
    }
}
