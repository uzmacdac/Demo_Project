package com.rsa.stepdefinitions;

import com.rsa.assertions.Assertions;
import com.rsa.context.ContextKey;
import com.rsa.context.TestContext;
import com.rsa.models.UserData;
import com.rsa.utils.RandomDataUtils;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegistrationSteps {

    private final TestContext context;

    public RegistrationSteps(TestContext context) {
        this.context = context;
    }

    @Given("I am on the registration page")
    public void iAmOnTheRegistrationPage() {
        context.pages().registerPage().open();
    }

    @When("I register a new user with random data")
    public void iRegisterANewUserWithRandomData() {
        UserData user = RandomDataUtils.randomUser();
        context.scenario().set(ContextKey.REGISTERED_USER, user);
        context.pages().registerPage().register(user);
    }

    @Then("I should see the account created confirmation")
    public void iShouldSeeTheAccountCreatedConfirmation() {
        Assertions.contains(context.pages().registerPage().getSuccessMessage(), "Account Created Successfully",
                "Registration success heading");
    }
}
