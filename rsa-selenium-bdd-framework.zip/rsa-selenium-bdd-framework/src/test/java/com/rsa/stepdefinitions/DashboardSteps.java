package com.rsa.stepdefinitions;

import java.util.List;

import com.rsa.assertions.Assertions;
import com.rsa.context.ContextKey;
import com.rsa.context.TestContext;
import com.rsa.models.OrderData;
import com.rsa.utils.DataReader;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DashboardSteps {

    private final TestContext context;

    public DashboardSteps(TestContext context) {
        this.context = context;
    }

    @When("I add product {string} to the cart")
    public void iAddProductToTheCart(String productName) {
        context.pages().dashboardPage().addProductToCart(productName);
        context.scenario().<String>getList(ContextKey.ADDED_PRODUCTS).add(productName);
    }

    @When("I add the following products to the cart:")
    public void iAddTheFollowingProductsToTheCart(DataTable table) {
        for (String product : table.asList()) {
            iAddProductToTheCart(product);
        }
    }

    @When("I add the products from order data {string}")
    public void iAddTheProductsFromOrderData(String orderKey) {
        OrderData order = DataReader.getOrder(orderKey);
        for (String product : order.getProducts()) {
            iAddProductToTheCart(product);
        }
    }

    @Then("the cart badge should show {int} item(s)")
    public void theCartBadgeShouldShowItems(int expected) {
        Assertions.areEqual(context.pages().header().getCartCount(), expected, "Cart badge count");
    }

    @Then("the dashboard should list product {string}")
    public void theDashboardShouldListProduct(String productName) {
        List<String> names = context.pages().dashboardPage().getProductNames();
        Assertions.isTrue(names.stream().anyMatch(n -> n.equalsIgnoreCase(productName)),
                "Dashboard lists '" + productName + "' (found " + names + ")");
    }
}
