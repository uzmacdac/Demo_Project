package com.rsa.stepdefinitions;

import java.util.List;

import com.rsa.assertions.Assertions;
import com.rsa.context.ContextKey;
import com.rsa.context.TestContext;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CartSteps {

    private final TestContext context;

    public CartSteps(TestContext context) {
        this.context = context;
    }

    /** The cart is stored server-side per account, so scenarios start by emptying it. */
    @Given("my cart is empty")
    public void myCartIsEmpty() {
        context.pages().header().goToCart().clearCart();
        context.pages().header().goToHome();
    }

    @When("I open the cart")
    public void iOpenTheCart() {
        context.pages().header().goToCart();
    }

    @When("I remove product {string} from the cart")
    public void iRemoveProductFromTheCart(String productName) {
        context.pages().cartPage().removeProduct(productName);
    }

    @When("I proceed to checkout")
    public void iProceedToCheckout() {
        context.pages().cartPage().checkout();
    }

    @Then("the cart should contain product {string}")
    public void theCartShouldContainProduct(String productName) {
        List<String> names = context.pages().cartPage().getProductNames();
        Assertions.isTrue(names.stream().anyMatch(n -> n.equalsIgnoreCase(productName)),
                "Cart contains '" + productName + "' (found " + names + ")");
    }

    @Then("the cart should not contain product {string}")
    public void theCartShouldNotContainProduct(String productName) {
        Assertions.isFalse(context.pages().cartPage().containsProduct(productName),
                "Cart does not contain '" + productName + "'");
    }

    @Then("the cart should contain the products I added")
    public void theCartShouldContainTheProductsIAdded() {
        List<String> expected = context.scenario().getList(ContextKey.ADDED_PRODUCTS);
        List<String> actual = context.pages().cartPage().getProductNames();
        for (String product : expected) {
            Assertions.isTrue(actual.stream().anyMatch(n -> n.equalsIgnoreCase(product)),
                    "Cart contains '" + product + "' (found " + actual + ")");
        }
    }

    @Then("the cart should be empty")
    public void theCartShouldBeEmpty() {
        Assertions.isTrue(context.pages().cartPage().isEmpty(), "Cart is empty");
    }
}
