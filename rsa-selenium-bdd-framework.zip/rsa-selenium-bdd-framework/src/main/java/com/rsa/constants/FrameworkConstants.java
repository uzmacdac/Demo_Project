package com.rsa.constants;

/** Central place for paths and route fragments so nothing is hard-coded in pages or steps. */
public final class FrameworkConstants {

    private FrameworkConstants() {
    }

    // output folders
    public static final String SCREENSHOT_DIR = "target/screenshots";
    public static final String ALLURE_RESULTS_DIR = "target/allure-results";

    // test data (classpath-relative, falls back to filesystem)
    public static final String USERS_JSON = "testdata/users.json";
    public static final String ORDERS_JSON = "testdata/orders.json";
    public static final String LOGIN_EXCEL = "testdata/LoginData.xlsx";
    public static final String LOGIN_SHEET = "LoginData";

    // Angular hash routes, appended to base.url
    public static final String LOGIN_PATH = "#/auth/login";
    public static final String REGISTER_PATH = "#/auth/register";
    public static final String DASHBOARD_PATH = "#/dashboard/dash";
}
