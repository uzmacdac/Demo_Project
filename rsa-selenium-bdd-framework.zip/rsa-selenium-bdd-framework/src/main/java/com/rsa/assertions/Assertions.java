package com.rsa.assertions;

import java.util.Collection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

/**
 * Hard assertions with logging. The first failure stops the step; the message is logged
 * before the AssertionError propagates to Cucumber / TestNG / the reports.
 */
public final class Assertions {

    private static final Logger LOG = LogManager.getLogger(Assertions.class);

    private Assertions() {
    }

    public static void isTrue(boolean condition, String description) {
        run(description, () -> Assert.assertTrue(condition, description));
    }

    public static void isFalse(boolean condition, String description) {
        run(description, () -> Assert.assertFalse(condition, description));
    }

    public static void areEqual(Object actual, Object expected, String description) {
        run(description, () -> Assert.assertEquals(actual, expected, description));
    }

    public static void equalsIgnoreCase(String actual, String expected, String description) {
        run(description, () -> Assert.assertTrue(
                actual != null && actual.trim().equalsIgnoreCase(expected.trim()),
                description + " | expected '" + expected + "' but was '" + actual + "'"));
    }

    public static void contains(String actual, String expectedPart, String description) {
        run(description, () -> Assert.assertTrue(
                actual != null && actual.toLowerCase().contains(expectedPart.toLowerCase()),
                description + " | expected '" + actual + "' to contain '" + expectedPart + "'"));
    }

    public static void notEmpty(Collection<?> collection, String description) {
        run(description, () -> Assert.assertTrue(collection != null && !collection.isEmpty(), description));
    }

    public static void notNull(Object value, String description) {
        run(description, () -> Assert.assertNotNull(value, description));
    }

    private static void run(String description, Runnable check) {
        try {
            check.run();
            LOG.info("PASS: {}", description);
        } catch (AssertionError e) {
            LOG.error("FAIL: {} -> {}", description, e.getMessage());
            throw e;
        }
    }
}
