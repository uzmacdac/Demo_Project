package com.rsa.assertions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.asserts.SoftAssert;

/**
 * Collects failures instead of stopping at the first one; call {@link #assertAll()} at the end
 * of the step to fail with every problem listed. Create one instance per step / scenario.
 */
public class SoftAssertions {

    private static final Logger LOG = LogManager.getLogger(SoftAssertions.class);

    private final SoftAssert soft = new SoftAssert();

    public SoftAssertions isTrue(boolean condition, String description) {
        soft.assertTrue(condition, description);
        LOG.info("SOFT {}: {}", condition ? "PASS" : "FAIL", description);
        return this;
    }

    public SoftAssertions areEqual(Object actual, Object expected, String description) {
        soft.assertEquals(actual, expected, description);
        LOG.info("SOFT {}: {}", java.util.Objects.equals(actual, expected) ? "PASS" : "FAIL", description);
        return this;
    }

    public void assertAll() {
        soft.assertAll();
    }
}
