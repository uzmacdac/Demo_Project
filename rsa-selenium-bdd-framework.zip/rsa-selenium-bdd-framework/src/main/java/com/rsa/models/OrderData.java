package com.rsa.models;

import java.util.ArrayList;
import java.util.List;

/** One entry of testdata/orders.json. */
public class OrderData {

    private List<String> products = new ArrayList<>();
    private String countryKeyword;
    private String country;

    public List<String> getProducts() {
        return products;
    }

    public void setProducts(List<String> products) {
        this.products = products;
    }

    public String getCountryKeyword() {
        return countryKeyword;
    }

    public void setCountryKeyword(String countryKeyword) {
        this.countryKeyword = countryKeyword;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
