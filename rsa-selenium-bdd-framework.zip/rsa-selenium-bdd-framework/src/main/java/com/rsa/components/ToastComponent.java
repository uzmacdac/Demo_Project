package com.rsa.components;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BaseComponent;

/** The ngx-toastr notification shown top-right ("Product Added To Cart", "Incorrect email or password."). */
public class ToastComponent extends BaseComponent {

    @FindBy(css = "#toast-container [role='alertdialog'], #toast-container .toast-message")
    private WebElement message;

    public ToastComponent(WebDriver driver) {
        super(driver);
    }

    /** Waits for a toast and returns its text. */
    public String getMessage() {
        return actions.getText(message, "Toast message");
    }

    /** Non-waiting read, returns "" when no toast is on screen. Used to enrich failure messages. */
    public String getMessageQuietly() {
        return actions.isDisplayed(message) ? message.getText().trim() : "";
    }

    /** Waits until a toast containing the text (case-insensitive) is visible. */
    public void waitForMessageContaining(String expected) {
        String needle = expected.toLowerCase();
        waits.until(d -> message.getText().toLowerCase().contains(needle));
    }
}
