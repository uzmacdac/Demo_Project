package com.rsa.components;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BaseComponent;
import com.rsa.pages.CartPage;
import com.rsa.pages.DashboardPage;
import com.rsa.pages.LoginPage;
import com.rsa.pages.OrdersPage;

/** The top navigation bar shown on every authenticated page (HOME, ORDERS, Cart, Sign Out). */
public class HeaderComponent extends BaseComponent {

    @FindBy(css = "button[routerlink*='dash']")
    private WebElement homeButton;

    @FindBy(css = "button[routerlink*='myorders']")
    private WebElement ordersButton;

    @FindBy(css = "button[routerlink*='cart']")
    private WebElement cartButton;

    @FindBy(css = "button[routerlink*='cart'] label")
    private WebElement cartCount;

    @FindBy(xpath = "//button[contains(normalize-space(.),'Sign Out')]")
    private WebElement signOutButton;

    public HeaderComponent(WebDriver driver) {
        super(driver);
    }

    public DashboardPage goToHome() {
        waits.angularIdle();
        actions.click(homeButton, "HOME");
        return new DashboardPage(driver).waitUntilLoaded();
    }

    public CartPage goToCart() {
        waits.angularIdle(); // the loading overlay swallows clicks on the cart button
        actions.click(cartButton, "Cart");
        return new CartPage(driver).waitUntilLoaded();
    }

    public OrdersPage goToOrders() {
        waits.angularIdle();
        actions.click(ordersButton, "ORDERS");
        return new OrdersPage(driver).waitUntilLoaded();
    }

    public LoginPage signOut() {
        waits.angularIdle();
        actions.click(signOutButton, "Sign Out");
        return new LoginPage(driver).waitUntilLoaded();
    }

    /** Number shown on the cart badge; 0 when the badge is absent. */
    public int getCartCount() {
        waits.angularIdle();
        if (!actions.isDisplayed(cartCount)) {
            return 0;
        }
        String digits = cartCount.getText().replaceAll("\\D", "");
        return digits.isEmpty() ? 0 : Integer.parseInt(digits);
    }
}
