package com.rsa.pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;

/** "Thankyou for the order." page shown after Place Order. */
public class OrderConfirmationPage extends BasePage {

    @FindBy(css = ".hero-primary")
    private WebElement confirmationMessage;

    /** Order ids are rendered as "| 6543abc... |" , one per ordered product. */
    @FindBy(css = ".em-spacer-1 .ng-star-inserted")
    private List<WebElement> orderIdElements;

    public OrderConfirmationPage(WebDriver driver) {
        super(driver);
    }

    public OrderConfirmationPage waitUntilLoaded() {
        waits.visible(confirmationMessage);
        return this;
    }

    public String getConfirmationMessage() {
        return actions.getText(confirmationMessage, "Order confirmation message");
    }

    public List<String> getOrderIds() {
        waits.until(d -> !orderIdElements.isEmpty());
        return orderIdElements.stream()
                .map(e -> e.getText().replace("|", "").trim())
                .filter(t -> !t.isEmpty())
                .collect(Collectors.toList());
    }
}
