package com.rsa.pages;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;
import com.rsa.components.HeaderComponent;
import com.rsa.components.ToastComponent;

/** https://rahulshettyacademy.com/client/#/dashboard/dash : the product catalogue. */
public class DashboardPage extends BasePage {

    private static final By PRODUCT_TITLE = By.cssSelector("b");
    private static final By ADD_TO_CART_BUTTON = By.cssSelector("button:last-of-type");

    @FindBy(css = ".card-body")
    private List<WebElement> productCards;

    private final HeaderComponent header;
    private final ToastComponent toast;

    public DashboardPage(WebDriver driver) {
        super(driver);
        this.header = new HeaderComponent(driver);
        this.toast = new ToastComponent(driver);
    }

    public DashboardPage waitUntilLoaded() {
        waits.urlContains("dashboard");
        waits.until(d -> !productCards.isEmpty());
        return this;
    }

    public List<String> getProductNames() {
        waitUntilLoaded();
        return productCards.stream()
                .map(card -> card.findElement(PRODUCT_TITLE).getText().trim())
                .collect(Collectors.toList());
    }

    public DashboardPage addProductToCart(String productName) {
        waitUntilLoaded();
        WebElement card = productCards.stream()
                .filter(c -> c.findElement(PRODUCT_TITLE).getText().trim().equalsIgnoreCase(productName))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException(
                        "Product '" + productName + "' not found. Available: " + getProductNames()));

        actions.click(card.findElement(ADD_TO_CART_BUTTON), "Add To Cart: " + productName);
        toast.waitForMessageContaining("Product Added To Cart");
        waits.angularIdle();
        return this;
    }

    public HeaderComponent header() {
        return header;
    }
}
