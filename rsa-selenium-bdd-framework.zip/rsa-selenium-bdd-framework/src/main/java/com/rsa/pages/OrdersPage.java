package com.rsa.pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;

/** https://rahulshettyacademy.com/client/#/dashboard/myorders : order history table. */
public class OrdersPage extends BasePage {

    private static final By ORDER_ID_CELL = By.cssSelector("th");
    private static final By PRODUCT_NAME_CELL = By.cssSelector("td:nth-child(3)");

    @FindBy(css = "tbody tr")
    private List<WebElement> orderRows;

    @FindBy(xpath = "//*[contains(normalize-space(text()),'No Orders')]")
    private WebElement noOrdersMessage;

    public OrdersPage(WebDriver driver) {
        super(driver);
    }

    /** Loaded once the table has rows or the "No Orders" message is shown. */
    public OrdersPage waitUntilLoaded() {
        waits.angularIdle();
        waits.until(d -> !orderRows.isEmpty() || actions.isDisplayed(noOrdersMessage));
        return this;
    }

    public List<String> getOrderIds() {
        waitUntilLoaded();
        return orderRows.stream()
                .map(row -> row.findElement(ORDER_ID_CELL).getText().trim())
                .collect(Collectors.toList());
    }

    public List<String> getProductNames() {
        waitUntilLoaded();
        return orderRows.stream()
                .map(row -> row.findElement(PRODUCT_NAME_CELL).getText().trim())
                .collect(Collectors.toList());
    }

    public boolean isOrderPresent(String orderId) {
        return getOrderIds().stream().anyMatch(id -> id.equalsIgnoreCase(orderId));
    }

    public boolean isProductPresent(String productName) {
        return getProductNames().stream().anyMatch(n -> n.equalsIgnoreCase(productName));
    }
}
