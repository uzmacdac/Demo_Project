package com.rsa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;
import com.rsa.constants.FrameworkConstants;
import com.rsa.models.UserData;

/** https://rahulshettyacademy.com/client/#/auth/register */
public class RegisterPage extends BasePage {

    @FindBy(id = "firstName")
    private WebElement firstNameInput;

    @FindBy(id = "lastName")
    private WebElement lastNameInput;

    @FindBy(id = "userEmail")
    private WebElement emailInput;

    @FindBy(id = "userMobile")
    private WebElement phoneInput;

    @FindBy(css = "select[formcontrolname='occupation']")
    private WebElement occupationSelect;

    @FindBy(css = "input[value='Male']")
    private WebElement maleRadio;

    @FindBy(css = "input[value='Female']")
    private WebElement femaleRadio;

    @FindBy(id = "userPassword")
    private WebElement passwordInput;

    @FindBy(id = "confirmPassword")
    private WebElement confirmPasswordInput;

    @FindBy(css = "input[type='checkbox']")
    private WebElement ageConfirmationCheckbox;

    @FindBy(id = "login")
    private WebElement registerButton;

    @FindBy(css = ".headcolor")
    private WebElement successHeading;

    @FindBy(xpath = "//button[normalize-space()='Login']")
    private WebElement goToLoginButton;

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    public RegisterPage open() {
        navigateTo(FrameworkConstants.REGISTER_PATH);
        return waitUntilLoaded();
    }

    public RegisterPage waitUntilLoaded() {
        waits.visible(firstNameInput);
        return this;
    }

    public RegisterPage register(UserData user) {
        actions.type(firstNameInput, user.getFirstName(), "First name");
        actions.type(lastNameInput, user.getLastName(), "Last name");
        actions.type(emailInput, user.getEmail(), "Email");
        actions.type(phoneInput, user.getPhone(), "Phone");
        actions.selectByVisibleText(occupationSelect, user.getOccupation(), "Occupation");
        actions.click("Female".equalsIgnoreCase(user.getGender()) ? femaleRadio : maleRadio, "Gender");
        actions.typeSecret(passwordInput, user.getPassword(), "Password");
        actions.typeSecret(confirmPasswordInput, user.getPassword(), "Confirm password");
        if (!actions.isSelected(ageConfirmationCheckbox)) {
            actions.click(ageConfirmationCheckbox, "Age confirmation");
        }
        actions.click(registerButton, "Register");
        return this;
    }

    /** Heading shown after a successful registration ("Account Created Successfully"). */
    public String getSuccessMessage() {
        return actions.getText(successHeading, "Registration success heading");
    }

    public LoginPage goToLogin() {
        actions.click(goToLoginButton, "Login (after registration)");
        return new LoginPage(driver).waitUntilLoaded();
    }
}
