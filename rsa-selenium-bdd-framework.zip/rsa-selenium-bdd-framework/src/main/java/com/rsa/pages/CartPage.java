package com.rsa.pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;

/** https://rahulshettyacademy.com/client/#/dashboard/cart */
public class CartPage extends BasePage {

    /** Each cart row has several .cartSection h3 nodes: the name, and the price ("MRP $ ..."). */
    @FindBy(css = ".cartSection h3")
    private List<WebElement> headings;

    @FindBy(css = ".cartSection button.btn-danger")
    private List<WebElement> removeButtons;

    @FindBy(css = ".totalRow button")
    private WebElement checkoutButton;

    @FindBy(xpath = "//h1[contains(normalize-space(.),'No Products')]")
    private WebElement emptyCartMessage;

    public CartPage(WebDriver driver) {
        super(driver);
    }

    /** The cart is loaded once it shows either items or the "No Products in Your Cart" message. */
    public CartPage waitUntilLoaded() {
        waits.urlContains("cart");
        waits.angularIdle();
        waits.until(d -> !headings.isEmpty() || actions.isDisplayed(emptyCartMessage));
        return this;
    }

    public List<String> getProductNames() {
        waitUntilLoaded();
        return headings.stream()
                .map(e -> e.getText().trim())
                .filter(t -> !t.isEmpty() && !t.toUpperCase().startsWith("MRP"))
                .collect(Collectors.toList());
    }

    public boolean containsProduct(String productName) {
        return getProductNames().stream().anyMatch(n -> n.equalsIgnoreCase(productName));
    }

    public boolean isEmpty() {
        waitUntilLoaded();
        return removeButtons.isEmpty();
    }

    public CartPage removeProduct(String productName) {
        waitUntilLoaded();
        By removeLocator = By.xpath("//h3[normalize-space()='" + productName
                + "']/ancestor::li//button[contains(@class,'btn-danger')]");
        int before = removeButtons.size();
        actions.click(driver.findElement(removeLocator), "Remove " + productName);
        waits.until(d -> removeButtons.size() < before);
        waits.angularIdle();
        return this;
    }

    /** Removes every item. The account's cart is server-side, so tests start from a known state. */
    public CartPage clearCart() {
        waitUntilLoaded();
        int guard = 0;
        while (!removeButtons.isEmpty() && guard++ < 25) {
            final int before = removeButtons.size();
            actions.click(removeButtons.get(0), "Remove first cart item");
            waits.until(d -> removeButtons.size() < before);
            waits.angularIdle();
        }
        return this;
    }

    public CheckoutPage checkout() {
        waitUntilLoaded();
        actions.click(checkoutButton, "Checkout");
        return new CheckoutPage(driver).waitUntilLoaded();
    }
}
