package com.rsa.pages;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;
import com.rsa.components.ToastComponent;
import com.rsa.constants.FrameworkConstants;

/** https://rahulshettyacademy.com/client/#/auth/login */
public class LoginPage extends BasePage {

    @FindBy(id = "userEmail")
    private WebElement emailInput;

    @FindBy(id = "userPassword")
    private WebElement passwordInput;

    @FindBy(id = "login")
    private WebElement loginButton;

    @FindBy(css = "a[routerlink*='register']")
    private WebElement registerLink;

    @FindBy(css = ".invalid-feedback")
    private List<WebElement> validationMessages;

    private final ToastComponent toast;

    public LoginPage(WebDriver driver) {
        super(driver);
        this.toast = new ToastComponent(driver);
    }

    public LoginPage open() {
        navigateTo(FrameworkConstants.LOGIN_PATH);
        return waitUntilLoaded();
    }

    public LoginPage waitUntilLoaded() {
        waits.visible(loginButton);
        return this;
    }

    /**
     * Fills the form and submits. Pressing TAB after each field marks it "touched" so Angular
     * renders its validation messages even when a field is left empty.
     */
    public LoginPage login(String email, String password) {
        actions.type(emailInput, email, "Email");
        actions.pressKey(emailInput, Keys.TAB, "Email");
        actions.typeSecret(passwordInput, password, "Password");
        actions.pressKey(passwordInput, Keys.TAB, "Password");
        actions.click(loginButton, "Login");
        return this;
    }

    /** Logs in and waits for the dashboard; fails with the on-screen toast text if login is rejected. */
    public DashboardPage loginSuccessfully(String email, String password) {
        login(email, password);
        try {
            return new DashboardPage(driver).waitUntilLoaded();
        } catch (TimeoutException e) {
            throw new IllegalStateException("Login did not reach the dashboard. URL=" + driver.getCurrentUrl()
                    + ", toast='" + toast.getMessageQuietly() + "'", e);
        }
    }

    public RegisterPage goToRegister() {
        actions.click(registerLink, "Register here");
        return new RegisterPage(driver).waitUntilLoaded();
    }

    public String getErrorToastMessage() {
        return toast.getMessage();
    }

    /** Field-level messages such as "*Email is required". */
    public List<String> getValidationMessages() {
        waits.until(d -> !validationMessages.isEmpty());
        return validationMessages.stream()
                .map(e -> e.getText().trim())
                .filter(t -> !t.isEmpty())
                .collect(Collectors.toList());
    }
}
