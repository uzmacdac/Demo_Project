package com.rsa.pages;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.rsa.base.BasePage;

/** Checkout / "Payment Method" page reached from the cart. */
public class CheckoutPage extends BasePage {

    @FindBy(css = "input[placeholder='Select Country']")
    private WebElement countryInput;

    @FindBy(css = ".ta-results button")
    private List<WebElement> countrySuggestions;

    @FindBy(css = ".action__submit")
    private WebElement placeOrderButton;

    public CheckoutPage(WebDriver driver) {
        super(driver);
    }

    public CheckoutPage waitUntilLoaded() {
        waits.visible(countryInput);
        return this;
    }

    /** Types a keyword in the auto-suggest field and clicks the suggestion whose text equals {@code country}. */
    public CheckoutPage selectCountry(String keyword, String country) {
        actions.type(countryInput, keyword, "Country");
        waits.until(d -> countrySuggestions.stream().anyMatch(s -> s.getText().trim().equalsIgnoreCase(country)));
        WebElement match = countrySuggestions.stream()
                .filter(s -> s.getText().trim().equalsIgnoreCase(country))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException(
                        "Country '" + country + "' was not suggested for keyword '" + keyword + "'"));
        actions.click(match, "Country " + country);
        return this;
    }

    public OrderConfirmationPage placeOrder() {
        actions.scrollIntoView(placeOrderButton);
        actions.click(placeOrderButton, "Place Order");
        return new OrderConfirmationPage(driver).waitUntilLoaded();
    }
}
