package com.rsa.retry;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import com.rsa.config.ConfigManager;

/**
 * Re-runs a failed Cucumber scenario up to retry.count times.
 * TestNG shares one analyzer instance across all data-provider rows (= scenarios) of the runner
 * method, so attempts are counted per scenario key, not in a single field.
 */
public class RetryAnalyzer implements IRetryAnalyzer {

    private static final Logger LOG = LogManager.getLogger(RetryAnalyzer.class);

    private final Map<String, Integer> attempts = new ConcurrentHashMap<>();
    private final int maxRetries = ConfigManager.get().getInt("retry.count", 0);

    @Override
    public boolean retry(ITestResult result) {
        String key = result.getMethod().getQualifiedName() + Arrays.toString(result.getParameters());
        int used = attempts.merge(key, 1, Integer::sum);
        if (used <= maxRetries) {
            LOG.warn("Retrying scenario {} (retry {}/{})", Arrays.toString(result.getParameters()), used, maxRetries);
            return true;
        }
        return false;
    }
}
