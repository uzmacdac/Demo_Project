package com.rsa.context;

import org.openqa.selenium.WebDriver;

import com.rsa.components.HeaderComponent;
import com.rsa.components.ToastComponent;
import com.rsa.pages.CartPage;
import com.rsa.pages.CheckoutPage;
import com.rsa.pages.DashboardPage;
import com.rsa.pages.LoginPage;
import com.rsa.pages.OrderConfirmationPage;
import com.rsa.pages.OrdersPage;
import com.rsa.pages.RegisterPage;

/** Lazily creates one instance of each page / component per scenario. */
public class PageObjectManager {

    private final WebDriver driver;

    private LoginPage loginPage;
    private RegisterPage registerPage;
    private DashboardPage dashboardPage;
    private CartPage cartPage;
    private CheckoutPage checkoutPage;
    private OrderConfirmationPage orderConfirmationPage;
    private OrdersPage ordersPage;
    private HeaderComponent header;
    private ToastComponent toast;

    public PageObjectManager(WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage loginPage() {
        return loginPage == null ? loginPage = new LoginPage(driver) : loginPage;
    }

    public RegisterPage registerPage() {
        return registerPage == null ? registerPage = new RegisterPage(driver) : registerPage;
    }

    public DashboardPage dashboardPage() {
        return dashboardPage == null ? dashboardPage = new DashboardPage(driver) : dashboardPage;
    }

    public CartPage cartPage() {
        return cartPage == null ? cartPage = new CartPage(driver) : cartPage;
    }

    public CheckoutPage checkoutPage() {
        return checkoutPage == null ? checkoutPage = new CheckoutPage(driver) : checkoutPage;
    }

    public OrderConfirmationPage orderConfirmationPage() {
        return orderConfirmationPage == null ? orderConfirmationPage = new OrderConfirmationPage(driver)
                : orderConfirmationPage;
    }

    public OrdersPage ordersPage() {
        return ordersPage == null ? ordersPage = new OrdersPage(driver) : ordersPage;
    }

    public HeaderComponent header() {
        return header == null ? header = new HeaderComponent(driver) : header;
    }

    public ToastComponent toast() {
        return toast == null ? toast = new ToastComponent(driver) : toast;
    }
}
