package com.rsa.context;

/** Typed keys for data shared between steps of one scenario. */
public enum ContextKey {
    CURRENT_USER,
    REGISTERED_USER,
    EXCEL_ROW,
    ADDED_PRODUCTS,
    ORDER_IDS
}
