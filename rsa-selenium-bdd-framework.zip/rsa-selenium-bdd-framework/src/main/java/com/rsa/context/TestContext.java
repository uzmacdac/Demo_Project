package com.rsa.context;

import org.openqa.selenium.WebDriver;

import com.rsa.base.DriverFactory;

/**
 * Injected by Cucumber PicoContainer into every step class and the hooks class.
 * One instance per scenario, so step classes share state without static fields.
 */
public class TestContext {

    private final ScenarioContext scenarioContext = new ScenarioContext();
    private PageObjectManager pageObjectManager;

    public WebDriver driver() {
        return DriverFactory.getDriver();
    }

    /** Created lazily because the driver is only started by the @Before hook. */
    public PageObjectManager pages() {
        if (pageObjectManager == null) {
            pageObjectManager = new PageObjectManager(driver());
        }
        return pageObjectManager;
    }

    public ScenarioContext scenario() {
        return scenarioContext;
    }
}
