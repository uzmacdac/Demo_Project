package com.rsa.context;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Key/value store that lives exactly as long as one scenario (one instance per scenario). */
public class ScenarioContext {

    private final Map<ContextKey, Object> store = new EnumMap<>(ContextKey.class);

    public void set(ContextKey key, Object value) {
        store.put(key, value);
    }

    public boolean has(ContextKey key) {
        return store.containsKey(key);
    }

    public <T> T get(ContextKey key, Class<T> type) {
        Object value = store.get(key);
        if (value == null) {
            throw new IllegalStateException("Nothing stored under " + key
                    + ". A previous step in this scenario has to set it first.");
        }
        return type.cast(value);
    }

    /** Returns the list stored under the key, creating an empty one on first use. */
    @SuppressWarnings("unchecked")
    public <T> List<T> getList(ContextKey key) {
        return (List<T>) store.computeIfAbsent(key, k -> new ArrayList<T>());
    }
}
