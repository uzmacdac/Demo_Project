package com.rsa.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Resolves which environment is active (-Denv=qa|stage|prod, default qa) and loads its
 * properties on top of config/common.properties.
 */
public final class EnvironmentManager {

    private static final Logger LOG = LogManager.getLogger(EnvironmentManager.class);
    private static final String COMMON_FILE = "config/common.properties";

    private EnvironmentManager() {
    }

    public static Environment current() {
        return Environment.from(System.getProperty("env", "qa"));
    }

    /** common.properties first, then the environment file overrides it. */
    public static Properties load() {
        Properties properties = new Properties();
        read(properties, COMMON_FILE);
        read(properties, current().propertiesFile());
        return properties;
    }

    private static void read(Properties target, String resource) {
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                throw new IllegalStateException("Config file not found on classpath: " + resource);
            }
            target.load(in);
            LOG.debug("Loaded config file {}", resource);
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read config file " + resource, e);
        }
    }
}
