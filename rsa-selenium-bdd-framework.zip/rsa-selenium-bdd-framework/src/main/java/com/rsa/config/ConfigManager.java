package com.rsa.config;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Thread-safe singleton giving typed access to configuration.
 * A JVM system property (-Dkey=value) always wins over the properties files.
 */
public final class ConfigManager {

    private static final Logger LOG = LogManager.getLogger(ConfigManager.class);

    private static final class Holder {
        private static final ConfigManager INSTANCE = new ConfigManager();
    }

    private final Properties properties;

    private ConfigManager() {
        this.properties = EnvironmentManager.load();
        LOG.info("Configuration loaded for environment '{}' ({} keys)", EnvironmentManager.current(), properties.size());
    }

    public static ConfigManager get() {
        return Holder.INSTANCE;
    }

    // ----- generic accessors ------------------------------------------------

    public String getString(String key) {
        String value = lookup(key);
        if (value == null) {
            throw new IllegalStateException(
                    "Missing config key '" + key + "' for environment '" + EnvironmentManager.current() + "'");
        }
        return value;
    }

    public String getString(String key, String defaultValue) {
        String value = lookup(key);
        return value == null ? defaultValue : value;
    }

    public int getInt(String key) {
        return Integer.parseInt(getString(key));
    }

    public int getInt(String key, int defaultValue) {
        String value = lookup(key);
        return value == null ? defaultValue : Integer.parseInt(value);
    }

    public boolean getBoolean(String key) {
        return Boolean.parseBoolean(getString(key));
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        String value = lookup(key);
        return value == null ? defaultValue : Boolean.parseBoolean(value);
    }

    // ----- convenience getters ----------------------------------------------

    /** Base URL, always ending with a slash. */
    public String getBaseUrl() {
        String url = getString("base.url");
        return url.endsWith("/") ? url : url + "/";
    }

    public String getBrowser() {
        return getString("browser").toLowerCase();
    }

    public boolean isHeadless() {
        return getBoolean("headless");
    }

    public String getDefaultUser() {
        return getString("default.user");
    }

    private String lookup(String key) {
        String fromSystem = System.getProperty(key);
        if (fromSystem != null && !fromSystem.isBlank()) {
            return fromSystem.trim();
        }
        String fromFile = properties.getProperty(key);
        return (fromFile == null || fromFile.isBlank()) ? null : fromFile.trim();
    }
}
