package com.rsa.config;

import java.util.Arrays;

/** Supported target environments. Each maps to config/&lt;name&gt;.properties. */
public enum Environment {
    QA,
    STAGE,
    PROD;

    public static Environment from(String value) {
        for (Environment env : values()) {
            if (env.name().equalsIgnoreCase(value == null ? "" : value.trim())) {
                return env;
            }
        }
        throw new IllegalArgumentException(
                "Unknown environment '" + value + "'. Supported: " + Arrays.toString(values()));
    }

    public String propertiesFile() {
        return "config/" + name().toLowerCase() + ".properties";
    }
}
