package com.rsa.listeners;

import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestListener;
import org.testng.ITestResult;

/** Logs the lifecycle of each Cucumber scenario as seen by TestNG (including retries). */
public class TestListener implements ITestListener {

    private static final Logger LOG = LogManager.getLogger(TestListener.class);

    @Override
    public void onTestStart(ITestResult result) {
        LOG.info("TESTNG START   : {}", Arrays.toString(result.getParameters()));
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        LOG.info("TESTNG PASSED  : {}", Arrays.toString(result.getParameters()));
    }

    @Override
    public void onTestFailure(ITestResult result) {
        LOG.error("TESTNG FAILED  : {} -> {}", Arrays.toString(result.getParameters()),
                result.getThrowable() == null ? "" : result.getThrowable().getMessage());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        LOG.warn("TESTNG SKIPPED : {} (a skip right after a failure means the scenario is being retried)",
                Arrays.toString(result.getParameters()));
    }
}
