package com.rsa.listeners;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.IAlterSuiteListener;
import org.testng.xml.XmlSuite;

import com.rsa.config.ConfigManager;

/**
 * Lets the number of parallel scenarios be set from config / -Dthread.count=N instead of
 * editing testng.xml. The Cucumber runner exposes scenarios through a parallel data provider,
 * and TestNG sizes that pool with the suite's data-provider-thread-count.
 */
public class ThreadCountAlterListener implements IAlterSuiteListener {

    private static final Logger LOG = LogManager.getLogger(ThreadCountAlterListener.class);

    @Override
    public void alter(List<XmlSuite> suites) {
        int threads = Math.max(1, ConfigManager.get().getInt("thread.count", 1));
        for (XmlSuite suite : suites) {
            suite.setDataProviderThreadCount(threads);
        }
        LOG.info("Parallel scenario threads: {}", threads);
    }
}
