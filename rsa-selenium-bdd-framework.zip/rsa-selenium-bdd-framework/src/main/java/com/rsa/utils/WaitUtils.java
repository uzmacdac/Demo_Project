package com.rsa.utils;

import java.time.Duration;
import java.util.List;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rsa.config.ConfigManager;

/**
 * All explicit waits live here. Implicit wait is 0, so nothing else in the framework waits silently.
 * Timeout and polling interval come from config (explicit.wait.seconds, polling.millis).
 */
public class WaitUtils {

    /** Angular shows this class on elements while its route / overlay animation runs. */
    private static final By ANGULAR_ANIMATING = By.cssSelector(".ng-animating");

    private final WebDriver driver;
    private final Duration timeout;
    private final Duration polling;

    public WaitUtils(WebDriver driver) {
        this(driver, Duration.ofSeconds(ConfigManager.get().getInt("explicit.wait.seconds")));
    }

    public WaitUtils(WebDriver driver, Duration timeout) {
        this.driver = driver;
        this.timeout = timeout;
        this.polling = Duration.ofMillis(ConfigManager.get().getInt("polling.millis", 250));
    }

    private WebDriverWait newWait() {
        WebDriverWait wait = new WebDriverWait(driver, timeout, polling);
        wait.ignoring(StaleElementReferenceException.class);
        return wait;
    }

    public WebElement visible(WebElement element) {
        return newWait().until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement visible(By locator) {
        return newWait().until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public WebElement clickable(WebElement element) {
        return newWait().until(ExpectedConditions.elementToBeClickable(element));
    }

    public boolean invisible(WebElement element) {
        return newWait().until(ExpectedConditions.invisibilityOf(element));
    }

    public List<WebElement> allVisible(List<WebElement> elements) {
        return newWait().until(ExpectedConditions.visibilityOfAllElements(elements));
    }

    public boolean urlContains(String fragment) {
        return newWait().until(ExpectedConditions.urlContains(fragment));
    }

    public boolean textPresent(WebElement element, String text) {
        return newWait().until(ExpectedConditions.textToBePresentInElement(element, text));
    }

    /** Waits until Angular has no running animation (loading overlay / route transition). */
    public void angularIdle() {
        newWait().until(d -> d.findElements(ANGULAR_ANIMATING).isEmpty());
    }

    public void pageReady() {
        newWait().until(d -> "complete".equals(((JavascriptExecutor) d).executeScript("return document.readyState")));
    }

    /** Escape hatch for custom conditions. The lambda may throw NoSuchElement; it is retried. */
    public <T> T until(Function<WebDriver, T> condition) {
        return newWait().until(condition);
    }
}
