package com.rsa.utils;

import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.rsa.constants.FrameworkConstants;
import com.rsa.models.OrderData;
import com.rsa.models.UserData;

/**
 * Single entry point for test data. Step definitions ask for data by key and never touch
 * files directly, so the storage format (JSON, Excel, later DB / API) can change in one place.
 */
public final class DataReader {

    private static volatile Map<String, UserData> users;
    private static volatile Map<String, OrderData> orders;

    private DataReader() {
    }

    public static UserData getUser(String key) {
        if (users == null) {
            synchronized (DataReader.class) {
                if (users == null) {
                    users = JsonUtils.read(FrameworkConstants.USERS_JSON, new TypeReference<Map<String, UserData>>() {
                    });
                }
            }
        }
        UserData user = users.get(key);
        if (user == null) {
            throw new IllegalArgumentException("No user '" + key + "' in " + FrameworkConstants.USERS_JSON
                    + ". Available: " + users.keySet());
        }
        return user;
    }

    public static OrderData getOrder(String key) {
        if (orders == null) {
            synchronized (DataReader.class) {
                if (orders == null) {
                    orders = JsonUtils.read(FrameworkConstants.ORDERS_JSON, new TypeReference<Map<String, OrderData>>() {
                    });
                }
            }
        }
        OrderData order = orders.get(key);
        if (order == null) {
            throw new IllegalArgumentException("No order '" + key + "' in " + FrameworkConstants.ORDERS_JSON
                    + ". Available: " + orders.keySet());
        }
        return order;
    }

    /** One row of LoginData.xlsx, looked up by its TestCaseId column. */
    public static Map<String, String> getLoginRow(String testCaseId) {
        return ExcelUtils.findRow(FrameworkConstants.LOGIN_EXCEL, FrameworkConstants.LOGIN_SHEET, "TestCaseId", testCaseId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "No row with TestCaseId '" + testCaseId + "' in " + FrameworkConstants.LOGIN_EXCEL));
    }
}
