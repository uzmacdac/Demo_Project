package com.rsa.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import com.rsa.config.ConfigManager;
import com.rsa.config.EnvironmentManager;
import com.rsa.constants.FrameworkConstants;

/** Report housekeeping: writes the "Environment" widget data Allure shows on its overview page. */
public final class ReportUtils {

    private ReportUtils() {
    }

    public static void writeAllureEnvironment() {
        ConfigManager config = ConfigManager.get();
        Properties env = new Properties();
        env.setProperty("Environment", EnvironmentManager.current().name());
        env.setProperty("BaseUrl", config.getBaseUrl());
        env.setProperty("Browser", config.getBrowser());
        env.setProperty("Headless", String.valueOf(config.isHeadless()));
        env.setProperty("ExecutionMode", config.getString("execution.mode"));
        env.setProperty("OS", System.getProperty("os.name"));
        env.setProperty("Java", System.getProperty("java.version"));

        try {
            Path dir = Paths.get(System.getProperty("allure.results.directory", FrameworkConstants.ALLURE_RESULTS_DIR));
            Files.createDirectories(dir);
            try (OutputStream out = Files.newOutputStream(dir.resolve("environment.properties"))) {
                env.store(out, "Allure environment");
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to write Allure environment.properties", e);
        }
    }
}
