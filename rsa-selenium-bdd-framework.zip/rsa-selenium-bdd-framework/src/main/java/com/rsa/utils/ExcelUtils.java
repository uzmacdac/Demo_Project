package com.rsa.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 * Reads an Excel sheet into a list of rows; each row is a map of header name to cell text.
 * The first row of the sheet is the header. Blank cells come back as empty strings.
 */
public final class ExcelUtils {

    private ExcelUtils() {
    }

    public static List<Map<String, String>> readSheet(String path, String sheetName) {
        try (InputStream in = ResourceUtils.open(path); Workbook workbook = WorkbookFactory.create(in)) {
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new IllegalArgumentException("Sheet '" + sheetName + "' not found in " + path);
            }
            Row headerRow = sheet.getRow(sheet.getFirstRowNum());
            if (headerRow == null) {
                return Collections.emptyList();
            }

            DataFormatter formatter = new DataFormatter();
            int columns = headerRow.getLastCellNum();
            List<String> headers = new ArrayList<>();
            for (int c = 0; c < columns; c++) {
                headers.add(formatter.formatCellValue(headerRow.getCell(c)).trim());
            }

            List<Map<String, String>> rows = new ArrayList<>();
            for (int r = sheet.getFirstRowNum() + 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) {
                    continue;
                }
                Map<String, String> values = new LinkedHashMap<>();
                boolean hasData = false;
                for (int c = 0; c < columns; c++) {
                    String text = formatter
                            .formatCellValue(row.getCell(c, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK))
                            .trim();
                    hasData |= !text.isEmpty();
                    values.put(headers.get(c), text);
                }
                if (hasData) {
                    rows.add(values);
                }
            }
            return rows;
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read Excel '" + path + "'", e);
        }
    }

    /** Finds the first row whose {@code keyColumn} equals {@code keyValue}. */
    public static Optional<Map<String, String>> findRow(String path, String sheetName, String keyColumn,
                                                        String keyValue) {
        return readSheet(path, sheetName).stream()
                .filter(row -> keyValue.equalsIgnoreCase(row.getOrDefault(keyColumn, "")))
                .findFirst();
    }
}
