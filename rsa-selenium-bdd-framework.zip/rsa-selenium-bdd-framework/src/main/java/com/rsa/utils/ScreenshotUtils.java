package com.rsa.utils;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.rsa.constants.FrameworkConstants;

public final class ScreenshotUtils {

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private ScreenshotUtils() {
    }

    public static byte[] asBytes(WebDriver driver) {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    /** Saves a PNG under target/screenshots and returns its path. */
    public static Path saveToFile(WebDriver driver, String name) {
        try {
            Path dir = Paths.get(FrameworkConstants.SCREENSHOT_DIR);
            Files.createDirectories(dir);
            String safeName = name.replaceAll("[^a-zA-Z0-9-_]", "_");
            Path file = dir.resolve(safeName + "_" + LocalDateTime.now().format(STAMP) + ".png");
            Files.write(file, asBytes(driver));
            return file;
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to save screenshot", e);
        }
    }
}
