package com.rsa.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Opens a resource from the classpath first, then from the file system. */
public final class ResourceUtils {

    private ResourceUtils() {
    }

    public static InputStream open(String path) throws IOException {
        InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
        if (stream != null) {
            return stream;
        }
        Path file = Paths.get(path);
        if (Files.exists(file)) {
            return Files.newInputStream(file);
        }
        throw new FileNotFoundException("Resource not found on classpath or file system: " + path);
    }
}
