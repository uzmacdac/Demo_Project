package com.rsa.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/** Small Jackson wrapper for reading (and writing) JSON test data. */
public final class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(SerializationFeature.INDENT_OUTPUT, true);

    private JsonUtils() {
    }

    public static <T> T read(String path, Class<T> type) {
        try (InputStream in = ResourceUtils.open(path)) {
            return MAPPER.readValue(in, type);
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read JSON '" + path + "'", e);
        }
    }

    public static <T> T read(String path, TypeReference<T> type) {
        try (InputStream in = ResourceUtils.open(path)) {
            return MAPPER.readValue(in, type);
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read JSON '" + path + "'", e);
        }
    }

    public static JsonNode readTree(String path) {
        try (InputStream in = ResourceUtils.open(path)) {
            return MAPPER.readTree(in);
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read JSON '" + path + "'", e);
        }
    }

    public static void write(String path, Object value) {
        try {
            Path target = Paths.get(path);
            if (target.getParent() != null) {
                Files.createDirectories(target.getParent());
            }
            MAPPER.writeValue(target.toFile(), value);
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to write JSON '" + path + "'", e);
        }
    }
}
