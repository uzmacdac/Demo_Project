package com.rsa.base;

import org.openqa.selenium.WebDriver;

import com.rsa.config.ConfigManager;

/** Base class of all page objects. Adds navigation helpers on top of {@link BaseComponent}. */
public abstract class BasePage extends BaseComponent {

    protected BasePage(WebDriver driver) {
        super(driver);
    }

    /** Opens base.url + the given Angular hash route, e.g. "#/auth/login". */
    protected void navigateTo(String route) {
        String url = ConfigManager.get().getBaseUrl() + route;
        log.info("Navigating to {}", url);
        actions.openUrl(url);
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public String getTitle() {
        return driver.getTitle();
    }
}
