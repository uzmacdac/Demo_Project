package com.rsa.base;

import java.net.MalformedURLException;
import java.net.URI;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.rsa.config.ConfigManager;

/**
 * Creates and owns the WebDriver of the current thread (ThreadLocal => safe for parallel scenarios).
 * Supports chrome / firefox / edge, headless, and a remote Selenium Grid (execution.mode=remote).
 */
public final class DriverFactory {

    private static final Logger LOG = LogManager.getLogger(DriverFactory.class);
    private static final ThreadLocal<WebDriver> DRIVER = new ThreadLocal<>();

    private DriverFactory() {
    }

    public static WebDriver getDriver() {
        WebDriver driver = DRIVER.get();
        if (driver == null) {
            throw new IllegalStateException("No WebDriver for thread '" + Thread.currentThread().getName()
                    + "'. It is created in the @Before hook; was the hook skipped?");
        }
        return driver;
    }

    public static boolean hasDriver() {
        return DRIVER.get() != null;
    }

    public static WebDriver initDriver() {
        ConfigManager config = ConfigManager.get();
        String browser = config.getBrowser();
        boolean headless = config.isHeadless();
        boolean remote = "remote".equalsIgnoreCase(config.getString("execution.mode"));

        LOG.info("Starting {} browser (headless={}, mode={})", browser, headless, remote ? "remote" : "local");

        MutableCapabilities options = buildOptions(browser, headless, config);
        WebDriver driver = remote ? createRemote(options, config) : createLocal(browser, options);

        driver.manage().timeouts().implicitlyWait(Duration.ZERO); // explicit waits only
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(config.getInt("page.load.timeout.seconds")));
        driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(config.getInt("script.timeout.seconds")));
        if (!headless && config.getBoolean("window.maximize", true)) {
            driver.manage().window().maximize();
        }

        DRIVER.set(driver);
        return driver;
    }

    public static void quitDriver() {
        WebDriver driver = DRIVER.get();
        if (driver != null) {
            try {
                driver.quit();
            } catch (RuntimeException e) {
                LOG.warn("Error while quitting the browser: {}", e.getMessage());
            } finally {
                DRIVER.remove();
            }
        }
    }

    // ----- internals ---------------------------------------------------------

    private static MutableCapabilities buildOptions(String browser, boolean headless, ConfigManager config) {
        String size = config.getString("window.size", "1920,1080");
        switch (browser) {
            case "chrome": {
                ChromeOptions options = new ChromeOptions();
                if (headless) {
                    options.addArguments("--headless=new", "--no-sandbox", "--disable-dev-shm-usage");
                }
                options.addArguments("--window-size=" + size, "--disable-notifications", "--disable-infobars",
                        "--disable-search-engine-choice-screen");
                options.setExperimentalOption("prefs", noPasswordPrompts());
                return options;
            }
            case "edge": {
                EdgeOptions options = new EdgeOptions();
                if (headless) {
                    options.addArguments("--headless=new", "--no-sandbox", "--disable-dev-shm-usage");
                }
                options.addArguments("--window-size=" + size, "--disable-notifications");
                options.setExperimentalOption("prefs", noPasswordPrompts());
                return options;
            }
            case "firefox": {
                FirefoxOptions options = new FirefoxOptions();
                if (headless) {
                    options.addArguments("-headless");
                }
                String[] wh = size.split(",");
                options.addArguments("--width=" + wh[0].trim(), "--height=" + wh[1].trim());
                return options;
            }
            default:
                throw new IllegalArgumentException("Unsupported browser '" + browser + "'. Use chrome, firefox or edge.");
        }
    }

    private static Map<String, Object> noPasswordPrompts() {
        Map<String, Object> prefs = new HashMap<>();
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.password_manager_enabled", false);
        prefs.put("profile.password_manager_leak_detection", false);
        return prefs;
    }

    private static WebDriver createLocal(String browser, MutableCapabilities options) {
        switch (browser) {
            case "chrome":
                return new ChromeDriver((ChromeOptions) options);
            case "edge":
                return new EdgeDriver((EdgeOptions) options);
            case "firefox":
                return new FirefoxDriver((FirefoxOptions) options);
            default:
                throw new IllegalArgumentException("Unsupported browser '" + browser + "'");
        }
    }

    private static WebDriver createRemote(MutableCapabilities options, ConfigManager config) {
        String gridUrl = config.getString("grid.url");
        try {
            return new RemoteWebDriver(URI.create(gridUrl).toURL(), options);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("Invalid grid.url '" + gridUrl + "'", e);
        }
    }
}
