package com.rsa.base;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.rsa.actions.WebActions;
import com.rsa.utils.WaitUtils;

/**
 * Root of everything that owns @FindBy fields (pages and reusable UI components).
 * PageFactory.initElements(driver, this) runs here, so every subclass gets lazy,
 * re-locating element proxies as soon as it is constructed.
 */
public abstract class BaseComponent {

    protected final Logger log = LogManager.getLogger(getClass());
    protected final WebDriver driver;
    protected final WaitUtils waits;
    protected final WebActions actions;

    protected BaseComponent(WebDriver driver) {
        this.driver = driver;
        this.waits = new WaitUtils(driver);
        this.actions = new WebActions(driver, waits);
        PageFactory.initElements(driver, this);
    }
}
