# Extent Reporting (Approach A: Extent Cucumber Adapter)

The framework uses `extentreports-cucumber7-adapter` (Spark reporter). The adapter is a Cucumber **plugin**:
it listens to Cucumber's event stream and builds the report itself, so there is **no custom ExtentReports /
ExtentTest / ThreadLocal manager code** to maintain. The framework's job is to (1) register and configure the
plugin, (2) feed it good data (screenshots, log lines, system info) and (3) keep per-thread state clean when
scenarios run in parallel.

## 1. The five pieces

| # | Piece | File | Role |
|---|---|---|---|
| 1 | Dependency | `pom.xml` (`extentreports-cucumber7-adapter`) | Brings the adapter and ExtentReports 5 |
| 2 | Plugin registration | `runners/TestRunner.java` | `"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"` (the trailing colon is required) |
| 3 | Report settings | `src/test/resources/extent.properties` | Where to write, base64 images, static system info |
| 4 | Look and feel | `src/test/resources/spark-config.xml` | Title, theme, timeline, timestamp format |
| 5 | Evidence | `hooks/Hooks.java`, `reporting/ReportLogger.java` | Screenshot on failure, log lines, retry marker |

## 2. What ends up in the report

| Report element | Source |
|---|---|
| Feature, Scenario, Scenario Outline row, each Gherkin step with pass/fail | Cucumber events, mapped by the adapter |
| Tags (`@smoke`, `@e2e` ...) as **categories** (Category tab / filters) | Gherkin tags, mapped by the adapter |
| Failure stack trace | Adapter, from the failed step's exception |
| Failure screenshot (embedded, base64) | `Hooks.afterStep` → `scenario.attach(png, "image/png", ...)` |
| Failing page URL | `Hooks.afterStep` → `scenario.log(...)` |
| Action trail under each step ("Clicked 'Login'", "Typed ******** into 'Password'") | `WebActions` → `ReportLogger.info(...)` → `scenario.log(...)` |
| Business facts (signed-in user, generated order ids) | Steps → `ReportLogger.info(...)` |
| Thread, browser and environment line at the start of each scenario | `Hooks.beforeScenario` |
| `RETRY: this is re-run number N ...` marker | `Hooks.beforeScenario` (see section 5) |
| Environment tab | `extent.properties` (static) + `pom.xml` `systeminfo.*` (dynamic) |
| Timeline view (shows scenarios overlapping in parallel runs) | `spark-config.xml` → `timelineEnabled=true` |

Passwords never reach the report: `typeSecret` logs `********`, and `UserData.toString()` omits the password.

## 3. Configuration reference (`extent.properties`)

| Key | Value here | Meaning |
|---|---|---|
| `extent.reporter.spark.start` | `true` | Enable the Spark reporter |
| `extent.reporter.spark.out` | `target/extent-reports/ExtentSpark.html` | Output file |
| `extent.reporter.spark.config` | `src/test/resources/spark-config.xml` | Spark XML config |
| `extent.reporter.spark.base64imagesrc` | `true` | Embed screenshots in the HTML (one portable file) |
| `systeminfo.<Name>` | Application, Framework, Author | Rows of the Environment tab |
| `basefolder.name`, `basefolder.datetimepattern` | commented out | Optional timestamped folder per run (then `out` is relative to it) |

Environment, Browser, Headless, OS and Java rows are produced from `pom.xml`:

```xml
<systeminfo.Environment>${env}</systeminfo.Environment>
<systeminfo.Browser>${browser}</systeminfo.Browser>
...
```
so `mvn test -Denv=stage -Dbrowser=firefox` shows exactly that in the report, with nothing to edit.

Every `extent.properties` key can also be overridden on the command line, for example
`-Dextent.reporter.spark.out=target/shard-1/report.html` to give each CI shard its own file.

## 4. Parallel execution

Run with `mvn test -Dthread.count=3`. How the pieces cooperate:

```
TestNG parallel @DataProvider (thread.count threads)
   ├─ thread-1: Scenario A ─┐
   ├─ thread-2: Scenario B ─┼─► Cucumber event bus ─► ExtentCucumberAdapter ─► ONE report, written at end of run
   └─ thread-3: Scenario C ─┘
```

**What the adapter does:** it keeps one report for the whole run and attributes each Cucumber event to the
feature / scenario it belongs to, so scenarios from different threads land in the same Spark file.
I could not find a statement about its thread-safety in the documentation pages I could reach, so treat this as
the library's design rather than something verified here, and confirm it with one parallel run (checklist below).

**What the framework does on its side (all in this repo):**

| Risk under parallel runs | Measure |
|---|---|
| Log line or screenshot attached to the wrong scenario | Scenario-scoped data goes through `scenario.attach/log` only, never through a shared static field |
| Framework code (no Cucumber access) needs to log into the report | `ReportLogger`: a `ThreadLocal` sink bound to `scenario::log` in `@Before`, removed in `@After` |
| Threads are reused by the pool, stale state leaks into the next scenario | `@After` always unbinds the sink and Log4j `ThreadContext` in a `finally` block |
| Impossible to tell interleaved log lines apart | Log4j pattern includes `[%t] [%X{scenario}]`, set from `ThreadContext` in `@Before` |
| Two failures in the same millisecond overwrite one screenshot file | Screenshot file name contains the thread id |
| Two parallel registrations generate the same email | `RandomDataUtils.randomEmail()` adds a UUID fragment |
| WebDriver shared between threads | `DriverFactory` uses `ThreadLocal<WebDriver>` |
| One scenario's retries consuming another's | `RetryAnalyzer` counts attempts per scenario key |

**Not solved by reporting, and still true:** parallel scenarios that log in as the same account share one
server-side cart and order history, so they can fail each other. Give each thread its own user before
raising `thread.count` for the cart and E2E features.

### Parallel verification checklist (run once)

```bash
mvn clean test -Dthread.count=3 -Dcucumber.filter.tags="@login"
```
1. Open `target/extent-reports/ExtentSpark.html` → **Timeline**: scenario bars should overlap.
2. Each scenario's first log line shows a different `Thread: ...` name.
3. Every scenario's steps and screenshot belong to that scenario (force a failure by changing a password in `users.json`).
4. `logs/automation.log`: the `[scenario]` column keeps each scenario's lines attributable.
5. The totals on the Dashboard equal the number of scenarios Cucumber printed.

## 5. Retries in the report

When `RetryAnalyzer` re-runs a failed scenario, Cucumber executes it again and the report shows it as a new
scenario entry with the same name. To make the two attempts distinguishable, `Hooks` counts how often each
scenario (feature URI + line) has started in the run and writes `RETRY: this is re-run number N ...` into the
second and later attempts. Attempts are keyed per scenario in a `ConcurrentHashMap`, so parallel scenarios cannot
disturb each other's count.

## 6. Customising

| Want | Do |
|---|---|
| A timestamped folder per run | Uncomment `basefolder.*` and set `out` to a relative name |
| Different title / theme | Edit `spark-config.xml` |
| A screenshot after every step | `-Dscreenshot.every.step=true` (report gets large with base64 images) |
| Extra Environment rows | Add `systeminfo.<Name>=...` to `extent.properties` or a `<systeminfo.Name>` in the pom |
| Log from a new page/util method | `ReportLogger.info("...")` (safe to call anywhere; no-op outside a scenario) |
| Attach a file / JSON | In a step: `scenario.attach(bytes, "application/json", "name")` (inject `Scenario` into a hook or keep it in `TestContext`) |

## 7. Troubleshooting

| Symptom | Check |
|---|---|
| No `ExtentSpark.html` | Plugin string in `TestRunner` must end with `:`; `extent.properties` must be on the test classpath (it is in `src/test/resources`) |
| Report exists but has no screenshots | `screenshot.on.failure=true` and `extent.reporter.spark.base64imagesrc=true` |
| Environment tab lacks Browser / Environment rows | The run must go through Maven (Surefire passes the `systeminfo.*` properties); an IDE run only shows the static rows |
| Scenario log lines missing | They are written with `scenario.log`; lines emitted before the `@Before` hook binds the sink are not captured |
| Report from an older run | `mvn clean test` (the output file is overwritten each run, unless `basefolder.*` is enabled) |
