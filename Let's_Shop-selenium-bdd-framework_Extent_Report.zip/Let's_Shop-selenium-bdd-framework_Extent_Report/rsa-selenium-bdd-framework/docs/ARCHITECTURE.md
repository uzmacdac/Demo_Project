# Architecture, Control Flow, Hooks and Execution Flow

## 1. Goals of the design

| Goal | How it is achieved |
|---|---|
| Readable tests | Gherkin features describe behaviour; no Selenium in features or steps |
| Maintainable UI code | Page Object Model + PageFactory: one class per screen, locators declared once with `@FindBy` |
| Stable tests | Explicit waits only (implicit wait is 0), Angular-aware waits, click-intercept fallback, scenario retry |
| Environment-agnostic | `-Denv` + properties files + `-D` overrides |
| Parallel-safe | `ThreadLocal<WebDriver>`, one `TestContext` per scenario, no static mutable state in steps |
| Debuggable | Log4j2 log, screenshot on failure in Extent + Allure, Allure environment widget |

## 2. Layered architecture

```
 ┌──────────────────────────────────────────────────────────────────────────────┐
 │ FEATURES  (src/test/resources/features/*.feature)      business language     │
 └───────────────────────────────────────┬──────────────────────────────────────┘
                                         │ matched by Cucumber expressions
 ┌───────────────────────────────────────▼──────────────────────────────────────┐
 │ STEP DEFINITIONS  (stepdefinitions/*Steps)   thin: call pages, assert        │
 │ HOOKS (hooks/Hooks)   browser lifecycle, evidence                            │
 └───────────────────────────────────────┬──────────────────────────────────────┘
                                         │ constructor injection (PicoContainer)
 ┌───────────────────────────────────────▼──────────────────────────────────────┐
 │ CONTEXT  TestContext ─► PageObjectManager, ScenarioContext                   │
 └───────────────────────────────────────┬──────────────────────────────────────┘
                                         │
 ┌───────────────────────────────────────▼──────────────────────────────────────┐
 │ PAGES + COMPONENTS   LoginPage … OrdersPage, HeaderComponent, ToastComponent │
 │ (@FindBy fields, business methods; extend BasePage / BaseComponent)          │
 └───────────────────────────────────────┬──────────────────────────────────────┘
                                         │
 ┌───────────────────────────────────────▼──────────────────────────────────────┐
 │ ACTIONS  WebActions  (click / type / select with wait + log + fallback)      │
 │ WAITS    WaitUtils   (all explicit waits, Angular idle)                      │
 └───────────────────────────────────────┬──────────────────────────────────────┘
                                         │
 ┌───────────────────────────────────────▼──────────────────────────────────────┐
 │ DRIVER   DriverFactory (ThreadLocal<WebDriver>, local or remote Grid)        │
 └──────────────────────────────────────────────────────────────────────────────┘

 Cross-cutting:  config (EnvironmentManager, ConfigManager) · utils (Excel, Json,
 DataReader, RandomData, Screenshot) · assertions · retry · listeners · reporting · logging
```

Dependency rule: **arrows only point downward**. Steps know pages; pages know actions/waits; nothing in
`src/main` knows about Cucumber glue, so the framework layer is reusable by other test suites.

## 3. Package responsibilities

| Package | Classes | Responsibility |
|---|---|---|
| `config` | `Environment`, `EnvironmentManager`, `ConfigManager` | Choose environment, load `common.properties` + `<env>.properties`, typed getters; `-D` always wins |
| `base` | `DriverFactory`, `BaseComponent`, `BasePage` | Driver creation/ownership; `BaseComponent` runs `PageFactory.initElements(driver, this)` and exposes `driver`, `waits`, `actions`, `log`; `BasePage` adds `navigateTo(route)` |
| `actions` | `WebActions` | `click`, `type`, `typeSecret`, `selectByVisibleText`, `isDisplayed`, `scrollIntoView`, `jsClick`… each waits and logs |
| `assertions` | `Assertions`, `SoftAssertions` | Hard assertions with PASS/FAIL logging; soft assertions that list all failures at `assertAll()` |
| `components` | `HeaderComponent`, `ToastComponent` | UI parts shared by many pages (top nav, toast) |
| `pages` | 7 page classes | One per screen; locators plus business methods (`login`, `addProductToCart`, `checkout`, `placeOrder`…) |
| `context` | `TestContext`, `ScenarioContext`, `ContextKey`, `PageObjectManager` | Per-scenario state and lazy page creation |
| `models` | `UserData`, `OrderData` | POJOs for JSON test data |
| `utils` | `WaitUtils`, `ExcelUtils`, `JsonUtils`, `DataReader`, `RandomDataUtils`, `ScreenshotUtils`, `ReportUtils`, `ResourceUtils` | Reusable helpers |
| `reporting` | `ReportLogger` | Lets pages/actions/utils write lines into the current scenario's Extent report (ThreadLocal sink) |
| `retry` | `RetryAnalyzer`, `RetryTransformer` | Re-run failed scenarios |
| `listeners` | `TestListener`, `ThreadCountAlterListener` | TestNG-level logging and parallelism control |
| `constants` | `FrameworkConstants` | Paths and route fragments |
| test: `hooks`, `runners`, `stepdefinitions` | `Hooks`, `TestRunner`, `FailedScenariosRunner`, `*Steps` | Cucumber layer |

## 4. Page Object + PageFactory pattern (as implemented)

```java
public class LoginPage extends BasePage {
    @FindBy(id = "userEmail")    private WebElement emailInput;     // 2. @FindBy defines elements
    @FindBy(id = "userPassword") private WebElement passwordInput;
    @FindBy(id = "login")        private WebElement loginButton;

    public LoginPage(WebDriver driver) { super(driver); }           // 3. initElements is in the base
}

public abstract class BaseComponent {
    protected BaseComponent(WebDriver driver) {
        ...
        PageFactory.initElements(driver, this);                     // 3. proxies created for every @FindBy
    }
}
```

What `initElements` gives us: each `WebElement` / `List<WebElement>` field is a **lazy proxy**. The lookup happens
on *every use*, which means a re-rendered Angular element does not cause `StaleElementReferenceException` in
normal use. Proxies are passed straight to `ExpectedConditions.visibilityOf(...)`, to `WebActions`, and to
`executeScript` (they implement `WrapsElement`).

Rules the pages follow:
* Locators are private; tests only see business methods.
* Page methods **return the next page** when navigation happens (`CartPage.checkout()` returns `CheckoutPage`) or
  `this` for fluent chaining. Page classes contain **no assertions**; they return data (`getProductNames()`) and
  the step definition asserts.
* Components (`HeaderComponent`, `ToastComponent`) are composed into pages, not inherited.

## 5. Control flow of one scenario

```
Cucumber engine                Hooks                Steps / Pages                Driver
───────────────                ─────                ─────────────                ──────
create TestContext (Pico)
create Hooks + *Steps (inject TestContext)
        │
        ├─► @Before(order=0) ──► log start ───────────────────────────────────► DriverFactory.initDriver()
        │                                                                         (ThreadLocal set)
        ├─► Step 1 ───────────────────────────► LoginSteps.iAmLoggedInAs
        │                                         context.pages().loginPage()    (PageObjectManager lazy-creates
        │                                           .open().loginSuccessfully()    LoginPage → initElements)
        │                                             WebActions.type/click
        │                                               WaitUtils.visible/clickable ──► WebDriver
        ├─► @AfterStep ─► if step failed (or screenshot.every.step) → attach PNG, save file, log URL
        ├─► Step 2 … N  (same pattern)
        └─► @After(order=0) ──► log status ──► DriverFactory.quitDriver() (ThreadLocal removed)
```

Data between steps travels through `context.scenario()` (`ScenarioContext`), e.g. `ADDED_PRODUCTS` is filled by
the "add product" step and read by "the cart should contain the products I added".

## 6. Hooks

| Hook | Scope | Runs | What it does |
|---|---|---|---|
| `@BeforeAll` | once per run | before the first scenario | create screenshot dir, write Allure `environment.properties`, log run banner |
| `@Before(order=0)` | each scenario | before step 1 | bind Log4j `ThreadContext` and `ReportLogger` to this scenario, count the attempt (retry marker), log scenario + tags, **start the browser**, log thread/browser/env into the report |
| `@AfterStep` | each step | after every step | on failure (`screenshot.on.failure`) or if `screenshot.every.step=true`: attach PNG to the scenario (Extent and Allure both render it), save the file, log failing URL |
| `@After(order=0)` | each scenario | after the last step, even if a step failed | log final status, **quit the browser**, then (in `finally`) release `ReportLogger` and `ThreadContext` so pooled threads start clean |
| `@AfterAll` | once per run | after the last scenario | log run end |

Why the screenshot is taken in `@AfterStep`, not `@After`: it captures the page at the instant of failure, before
any teardown, and one failed step produces exactly one image.

Hook ordering note: Cucumber runs `@Before` hooks in ascending `order` and `@After` hooks in **descending**
order. Anything you add later that needs the browser alive (for example a log dump) must use an `@After` order
**higher** than the driver-quit hook.

## 7. End-to-end execution flow (from the command line to the report)

```
mvn clean test -Dbrowser=chrome -Dcucumber.filter.tags="@smoke"
 │
 1. Maven resolves pom properties (env, browser, headless, tags) → Surefire systemPropertyVariables
 │
 2. Surefire forks a JVM and runs src/test/resources/testng.xml
 │     listeners registered from the XML:
 │       • ThreadCountAlterListener  → sets data-provider-thread-count from thread.count
 │       • TestListener              → logs TestNG start / pass / fail / skip
 │       • RetryTransformer          → attaches RetryAnalyzer to the runner's test method
 │
 3. TestNG instantiates TestRunner (extends AbstractTestNGCucumberTests)
 │     @CucumberOptions: features dir, glue (stepdefinitions + hooks), plugins
 │
 4. scenarios() @DataProvider(parallel = true)
 │     Cucumber parses features, applies cucumber.filter.tags, returns one row per scenario
 │     (Scenario Outline rows each become a scenario)
 │
 5. TestNG calls runScenario(...) once per row, on up to thread.count threads
 │
 6. For each scenario (own thread):
 │     @BeforeAll (once) → PicoContainer creates TestContext → @Before → steps (+ @AfterStep) → @After
 │
 7. A failed scenario → RetryAnalyzer.retry() → true while attempts < retry.count → scenario runs again
 │     (attempts are counted per scenario, so one flaky scenario cannot use up another's retries)
 │
 8. Plugins stream events during the run:
 │     • ExtentCucumberAdapter      → target/extent-reports/ExtentSpark.html
 │     • AllureCucumber7Jvm         → target/allure-results/*.json   (+ environment.properties from @BeforeAll)
 │     • html / json                → target/cucumber-reports/
 │     • rerun                      → target/rerun.txt (failed scenarios, input of FailedScenariosRunner)
 │
 9. @AfterAll → Surefire summary → exit code (non-zero if any scenario failed after retries)
```

## 8. Configuration flow

```
-Dkey=value (command line / Surefire)  ─┐
config/<env>.properties                 ─┼─► ConfigManager.lookup(key)  (first non-blank wins, top to bottom)
config/common.properties                ─┘
```

* `EnvironmentManager.current()` reads `-Denv` (default `qa`) and validates it against the `Environment` enum, so
  a typo fails immediately with the list of valid values.
* `ConfigManager` is a lazy, thread-safe singleton (initialization-on-demand holder).
* Add a key: put it in `common.properties`, override per environment, read it with `ConfigManager.get().getX(...)`.

## 9. Test data flow

```
Feature file (keys only: "standard_user", "single_item_order", "invalid_password")
   └─► Step definition ─► DataReader ─┬─► JsonUtils  ─► users.json / orders.json ─► UserData / OrderData
                                      ├─► ExcelUtils ─► LoginData.xlsx (sheet LoginData, key column TestCaseId)
                                      └─► RandomDataUtils (registration: unique email, phone, password)
```

Steps never open files. `ResourceUtils` resolves a path on the classpath first, then on disk. Replace
the storage later (database, API) by changing only `DataReader`.

## 10. Synchronisation strategy

| Situation | Technique | Where |
|---|---|---|
| Element must be visible / clickable | `ExpectedConditions` | `WaitUtils.visible / clickable` |
| Angular loading overlay or route animation | wait for `.ng-animating` to be gone | `WaitUtils.angularIdle()` before clicking cart/home/orders |
| Add to cart finished | wait for toast text "Product Added To Cart" | `DashboardPage.addProductToCart` |
| List-based screens (cart, orders) | wait for "rows exist OR empty message shown" | `CartPage/OrdersPage.waitUntilLoaded` |
| Auto-suggest country list | wait until the exact country is among the suggestions | `CheckoutPage.selectCountry` |
| Click swallowed by an overlay | catch `ElementClickInterceptedException`, retry via JavaScript click | `WebActions.click` |
| Stale element | `StaleElementReferenceException` ignored in every wait; PageFactory proxies re-locate | `WaitUtils.newWait` |

There is no `Thread.sleep` and the implicit wait is 0, so a timeout always points at the element that was awaited.

## 11. Reporting and logging

* **Extent Spark** (Approach A, the Extent Cucumber adapter plugin): `extent.properties` + `spark-config.xml`;
  screenshots arrive as base64 through `scenario.attach`; framework code writes report lines through
  `ReportLogger` (a thread-bound sink onto `scenario.log`); Environment tab filled from `pom.xml` `systeminfo.*`.
  Full details and the parallel-run checklist: `docs/EXTENT_REPORTING.md`.
* **Allure**: results written to `target/allure-results`; `Hooks.beforeAll` adds the Environment widget data.
  Each Cucumber step appears as an Allure step automatically. Run `mvn allure:serve`.
* **Log4j2** (`log4j2.xml`): console + rolling file `logs/automation.log`, pattern includes thread name, so
  parallel runs can be separated by thread. `com.rsa` logs at DEBUG, everything else at INFO. Passwords are never
  logged (`typeSecret`, and `UserData.toString` omits the password).

## 12. Retry and parallel execution

* **Retry**: `retry.count` (default 1). A retried attempt shows up in TestNG as *skipped* followed by the next
  attempt; Extent/Allure show both attempts, which is useful for spotting flaky scenarios.
* **Parallel**: set `-Dthread.count=N`. Each thread owns its driver and its `TestContext`. Shared **server-side**
  state is the only hazard (the demo account's cart and orders), so use a distinct user per thread before raising N.

## 13. How to extend

| Task | Steps |
|---|---|
| New page | class in `pages` extending `BasePage`; `@FindBy` fields; business methods; accessor in `PageObjectManager` |
| New reusable widget | class in `components` extending `BaseComponent` |
| New scenario | `.feature` file; reuse existing steps, add new ones to the matching `*Steps` class |
| New data set | add keys to `users.json` / `orders.json`, or rows to `LoginData.xlsx` |
| New browser option | `DriverFactory.buildOptions` |
| Run on a Grid | `-Dexecution.mode=remote -Dgrid.url=http://host:4444` |
| Allure `@Step` on page methods | add the `aspectjweaver` agent to Surefire `argLine` (not needed for the current setup) |

## 14. Troubleshooting

| Symptom | Likely cause |
|---|---|
| `Login did not reach the dashboard ... toast='Incorrect email or password.'` | demo account changed; update `users.json` |
| `TimeoutException` on a locator | site DOM differs; check the ⚠ locators in `SITE_ANALYSIS.md` first |
| Cart assertions flaky when parallel | threads share one account; use distinct users |
| No Extent report | check `extent.properties` is on the classpath and the plugin string in `TestRunner` ends with `:` |
| `No WebDriver for thread` | scenario ran without the `@Before` hook; confirm `com.rsa.hooks` is in the glue |
| Allure shows no history/environment | run `mvn clean test` so old results do not mix, then `mvn allure:serve` |
