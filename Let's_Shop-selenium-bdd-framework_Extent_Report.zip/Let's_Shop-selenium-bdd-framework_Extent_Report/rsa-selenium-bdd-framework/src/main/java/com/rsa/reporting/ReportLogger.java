package com.rsa.reporting;

import java.util.function.Consumer;

/**
 * Lets framework code (pages, actions, utils) write a line into the report of the scenario that is
 * running on the CURRENT thread, without depending on Cucumber.
 *
 * How it stays parallel-safe: a scenario runs start to finish on one thread, so a ThreadLocal sink
 * bound in the @Before hook (to {@code scenario::log}) always points at the right scenario. The
 * Extent adapter then shows the line under the step that was executing. When no sink is bound
 * (code running outside a scenario) the call is a silent no-op.
 */
public final class ReportLogger {

    private static final ThreadLocal<Consumer<String>> SINK = new ThreadLocal<>();

    private ReportLogger() {
    }

    public static void bind(Consumer<String> sink) {
        SINK.set(sink);
    }

    public static void unbind() {
        SINK.remove();
    }

    public static void info(String message) {
        Consumer<String> sink = SINK.get();
        if (sink != null) {
            sink.accept(message);
        }
    }
}
