package com.rsa.utils;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import com.rsa.models.UserData;

/** Generates unique, valid-looking data for the registration form. */
public final class RandomDataUtils {

    private static final String[] FIRST_NAMES = {"Aarav", "Vivaan", "Diya", "Ishaan", "Meera", "Kabir", "Anaya", "Rohan"};
    private static final String[] LAST_NAMES = {"Sharma", "Patil", "Kulkarni", "Iyer", "Nair", "Desai", "Joshi", "Reddy"};
    private static final String[] GENDERS = {"Male", "Female"};

    private RandomDataUtils() {
    }

    public static String randomNumeric(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(ThreadLocalRandom.current().nextInt(10));
        }
        return sb.toString();
    }

    public static String randomEmail() {
        // UUID fragment, not just a timestamp: parallel scenarios can register within the same millisecond
        return ("rsa.auto." + System.currentTimeMillis() + "." + UUID.randomUUID().toString().substring(0, 8)
                + "@example.com").toLowerCase();
    }

    /** 10-digit mobile number starting with 9. */
    public static String randomPhone() {
        return "9" + randomNumeric(9);
    }

    /** Meets typical rules: upper + lower + digit + special, 10 characters. */
    public static String randomPassword() {
        return "Rsa@" + randomNumeric(6);
    }

    public static UserData randomUser() {
        UserData user = new UserData();
        user.setFirstName(pick(FIRST_NAMES));
        user.setLastName(pick(LAST_NAMES));
        user.setEmail(randomEmail());
        user.setPhone(randomPhone());
        user.setPassword(randomPassword());
        user.setOccupation("Engineer");
        user.setGender(pick(GENDERS));
        return user;
    }

    private static String pick(String[] values) {
        return values[ThreadLocalRandom.current().nextInt(values.length)];
    }
}
