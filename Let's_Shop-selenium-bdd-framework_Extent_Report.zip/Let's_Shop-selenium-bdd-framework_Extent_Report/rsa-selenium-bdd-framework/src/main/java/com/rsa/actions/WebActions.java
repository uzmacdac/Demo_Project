package com.rsa.actions;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.rsa.reporting.ReportLogger;
import com.rsa.utils.WaitUtils;

/**
 * Thin, logged wrappers over raw WebElement calls. Page objects call these instead of
 * element.click() / sendKeys() so every interaction waits, logs and handles the common
 * Angular flake (a click intercepted by an overlay) in exactly one place.
 */
public class WebActions {

    private static final Logger LOG = LogManager.getLogger(WebActions.class);

    private final WebDriver driver;
    private final WaitUtils waits;

    public WebActions(WebDriver driver, WaitUtils waits) {
        this.driver = driver;
        this.waits = waits;
    }

    public void openUrl(String url) {
        driver.get(url);
        waits.pageReady();
    }

    public void click(WebElement element, String name) {
        waits.clickable(element);
        try {
            element.click();
        } catch (ElementClickInterceptedException e) {
            LOG.warn("Click on '{}' was intercepted, retrying with JavaScript", name);
            jsClick(element);
        }
        LOG.info("Clicked '{}'", name);
        ReportLogger.info("Clicked '" + name + "'");
    }

    public void jsClick(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    public void type(WebElement element, String text, String name) {
        waits.visible(element);
        element.clear();
        if (text != null && !text.isEmpty()) {
            element.sendKeys(text);
        }
        LOG.info("Typed '{}' into '{}'", text, name);
        ReportLogger.info("Typed '" + text + "' into '" + name + "'");
    }

    /** Same as {@link #type} but never writes the value to the log. */
    public void typeSecret(WebElement element, String text, String name) {
        waits.visible(element);
        element.clear();
        if (text != null && !text.isEmpty()) {
            element.sendKeys(text);
        }
        LOG.info("Typed ******** into '{}'", name);
        ReportLogger.info("Typed ******** into '" + name + "'"); // secrets never reach the report
    }

    public void pressKey(WebElement element, CharSequence key, String name) {
        element.sendKeys(key);
        LOG.debug("Pressed key in '{}'", name);
    }

    public String getText(WebElement element, String name) {
        String text = waits.visible(element).getText().trim();
        LOG.debug("Text of '{}' = '{}'", name, text);
        return text;
    }

    public void selectByVisibleText(WebElement select, String text, String name) {
        waits.visible(select);
        new Select(select).selectByVisibleText(text);
        LOG.info("Selected '{}' in '{}'", text, name);
        ReportLogger.info("Selected '" + text + "' in '" + name + "'");
    }

    public void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
    }

    public void hover(WebElement element) {
        new Actions(driver).moveToElement(element).perform();
    }

    /** Non-waiting check; false if the element is absent, stale or hidden. */
    public boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }

    /** Waiting check; false if the element does not become visible within the explicit wait. */
    public boolean becomesVisible(WebElement element) {
        try {
            waits.visible(element);
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public boolean isSelected(WebElement element) {
        return element.isSelected();
    }
}
