package com.rsa.stepdefinitions;

import java.util.List;

import com.rsa.assertions.Assertions;
import com.rsa.context.ContextKey;
import com.rsa.context.TestContext;
import com.rsa.models.OrderData;
import com.rsa.pages.OrderConfirmationPage;
import com.rsa.reporting.ReportLogger;
import com.rsa.utils.DataReader;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CheckoutSteps {

    private final TestContext context;

    public CheckoutSteps(TestContext context) {
        this.context = context;
    }

    @When("I select country {string} by typing {string}")
    public void iSelectCountryByTyping(String country, String keyword) {
        context.pages().checkoutPage().selectCountry(keyword, country);
    }

    @When("I place the order")
    public void iPlaceTheOrder() {
        context.pages().checkoutPage().placeOrder();
    }

    @When("I complete checkout with order data {string}")
    public void iCompleteCheckoutWithOrderData(String orderKey) {
        OrderData order = DataReader.getOrder(orderKey);
        context.pages().checkoutPage()
                .selectCountry(order.getCountryKeyword(), order.getCountry())
                .placeOrder();
    }

    @Then("I should see the order confirmation message {string}")
    public void iShouldSeeTheOrderConfirmationMessage(String expected) {
        OrderConfirmationPage page = context.pages().orderConfirmationPage().waitUntilLoaded();
        // the page upper-cases the heading with CSS, so compare ignoring case
        Assertions.equalsIgnoreCase(page.getConfirmationMessage(), expected, "Order confirmation message");
    }

    @Then("an order id should be generated")
    public void anOrderIdShouldBeGenerated() {
        List<String> orderIds = context.pages().orderConfirmationPage().getOrderIds();
        Assertions.notEmpty(orderIds, "Order id(s) shown on the confirmation page");
        context.scenario().set(ContextKey.ORDER_IDS, orderIds);
        ReportLogger.info("Generated order id(s): " + orderIds);
    }
}
