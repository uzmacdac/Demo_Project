package com.rsa.hooks;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import com.rsa.base.DriverFactory;
import com.rsa.config.ConfigManager;
import com.rsa.config.EnvironmentManager;
import com.rsa.constants.FrameworkConstants;
import com.rsa.context.TestContext;
import com.rsa.reporting.ReportLogger;
import com.rsa.utils.ReportUtils;
import com.rsa.utils.ScreenshotUtils;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;

/**
 * Cucumber lifecycle hooks.
 *
 * Order for one scenario:  @Before (browser starts)  ->  steps (each followed by @AfterStep)  ->  @After (browser quits).
 * @BeforeAll / @AfterAll run once per test run, outside any scenario.
 *
 * Parallel safety: everything per-scenario is bound to the current thread here (WebDriver, Log4j
 * ThreadContext, ReportLogger sink) and released in @After. The Extent report itself is produced by
 * the Extent Cucumber adapter plugin, which aggregates all threads into one report at the end of the run.
 */
public class Hooks {

    private static final Logger LOG = LogManager.getLogger(Hooks.class);

    /** How many times each scenario (feature uri + line) has started in this run; > 1 means a retry. */
    private static final Map<String, Integer> ATTEMPTS = new ConcurrentHashMap<>();

    private final TestContext context;

    public Hooks(TestContext context) {
        this.context = context;
    }

    @BeforeAll
    public static void beforeAll() throws Exception {
        Files.createDirectories(Paths.get(FrameworkConstants.SCREENSHOT_DIR));
        ReportUtils.writeAllureEnvironment();
        LOG.info("==== RUN START | env={} | browser={} | headless={} ====", EnvironmentManager.current(),
                ConfigManager.get().getBrowser(), ConfigManager.get().isHeadless());
    }

    @Before(order = 0)
    public void beforeScenario(Scenario scenario) {
        // 1. bind per-thread diagnostics first so every later line is attributed to this scenario
        ThreadContext.put("scenario", scenario.getName());
        ReportLogger.bind(scenario::log);

        int attempt = ATTEMPTS.merge(scenario.getUri() + ":" + scenario.getLine(), 1, Integer::sum);
        LOG.info("---- SCENARIO START: '{}' {} (attempt {}) ----", scenario.getName(), scenario.getSourceTagNames(), attempt);

        // 2. start the browser
        DriverFactory.initDriver();

        // 3. facts that make a parallel / retried run readable in the Extent report
        ReportLogger.info("Thread: " + Thread.currentThread().getName()
                + " | Browser: " + ConfigManager.get().getBrowser()
                + " | Env: " + EnvironmentManager.current());
        if (attempt > 1) {
            ReportLogger.info("RETRY: this is re-run number " + (attempt - 1) + " of a previously failed scenario");
        }
    }

    @AfterStep
    public void afterStep(Scenario scenario) {
        if (!DriverFactory.hasDriver()) {
            return;
        }
        ConfigManager config = ConfigManager.get();
        boolean failedStep = scenario.isFailed() && config.getBoolean("screenshot.on.failure", true);
        boolean everyStep = config.getBoolean("screenshot.every.step", false);
        if (failedStep || everyStep) {
            byte[] png = ScreenshotUtils.asBytes(context.driver());
            // embedded as base64 into the Extent (Spark) report and attached to Allure
            scenario.attach(png, "image/png", failedStep ? "Failure screenshot" : "Step screenshot");
            if (failedStep) {
                ScreenshotUtils.saveToFile(context.driver(), scenario.getName());
                scenario.log("Failed at URL: " + context.driver().getCurrentUrl());
            }
        }
    }

    @After(order = 0)
    public void afterScenario(Scenario scenario) {
        LOG.info("---- SCENARIO END  : '{}' -> {} ----", scenario.getName(), scenario.getStatus());
        try {
            DriverFactory.quitDriver();
        } finally {
            // thread pools reuse threads: always release per-thread state, even if quit() threw
            ReportLogger.unbind();
            ThreadContext.remove("scenario");
        }
    }

    @AfterAll
    public static void afterAll() {
        LOG.info("==== RUN END ====");
    }
}
