package com.rsa.stepdefinitions;

import java.util.List;
import java.util.Map;

import com.rsa.assertions.Assertions;
import com.rsa.context.ContextKey;
import com.rsa.context.TestContext;
import com.rsa.models.UserData;
import com.rsa.pages.LoginPage;
import com.rsa.reporting.ReportLogger;
import com.rsa.utils.DataReader;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

    private final TestContext context;

    public LoginSteps(TestContext context) {
        this.context = context;
    }

    @Given("I am on the login page")
    public void iAmOnTheLoginPage() {
        context.pages().loginPage().open();
    }

    /** Shortcut used by Background sections: opens the login page and signs in via the UI. */
    @Given("I am logged in as {string}")
    public void iAmLoggedInAs(String userKey) {
        UserData user = DataReader.getUser(userKey);
        ReportLogger.info("Signing in as '" + userKey + "' (" + user.getEmail() + ")");
        context.scenario().set(ContextKey.CURRENT_USER, user);
        context.pages().loginPage().open().loginSuccessfully(user.getEmail(), user.getPassword());
    }

    @Given("I login with the newly registered user")
    public void iLoginWithTheNewlyRegisteredUser() {
        UserData user = context.scenario().get(ContextKey.REGISTERED_USER, UserData.class);
        context.scenario().set(ContextKey.CURRENT_USER, user);
        context.pages().loginPage().open().loginSuccessfully(user.getEmail(), user.getPassword());
    }

    @When("I login as {string}")
    public void iLoginAs(String userKey) {
        UserData user = DataReader.getUser(userKey);
        context.scenario().set(ContextKey.CURRENT_USER, user);
        context.pages().loginPage().login(user.getEmail(), user.getPassword());
    }

    @When("I login using Excel test data {string}")
    public void iLoginUsingExcelTestData(String testCaseId) {
        Map<String, String> row = DataReader.getLoginRow(testCaseId);
        context.scenario().set(ContextKey.EXCEL_ROW, row);
        context.pages().loginPage().login(row.get("Email"), row.get("Password"));
    }

    @Then("I should land on the dashboard")
    public void iShouldLandOnTheDashboard() {
        context.pages().dashboardPage().waitUntilLoaded();
        Assertions.contains(context.driver().getCurrentUrl(), "dashboard", "Current URL is a dashboard URL");
    }

    @Then("the dashboard should display products")
    public void theDashboardShouldDisplayProducts() {
        Assertions.notEmpty(context.pages().dashboardPage().getProductNames(), "Dashboard lists products");
    }

    @SuppressWarnings("unchecked")
    @Then("I should see the expected login error")
    public void iShouldSeeTheExpectedLoginError() {
        Map<String, String> row = context.scenario().get(ContextKey.EXCEL_ROW, Map.class);
        String expected = row.get("ExpectedMessage");
        LoginPage loginPage = context.pages().loginPage();

        if ("TOAST".equalsIgnoreCase(row.get("ErrorType"))) {
            Assertions.contains(loginPage.getErrorToastMessage(), expected, "Login error toast");
        } else {
            List<String> messages = loginPage.getValidationMessages();
            Assertions.isTrue(
                    messages.stream().anyMatch(m -> m.toLowerCase().contains(expected.toLowerCase())),
                    "Validation messages " + messages + " should contain '" + expected + "'");
        }
    }
}
